module.exports = {
  transpileDependencies: true,
  lintOnSave:false
}
