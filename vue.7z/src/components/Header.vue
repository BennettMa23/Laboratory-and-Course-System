<template>
    <div style="line-height: 60px; display: flex" @mousemove="handleTime"  v-if="isRouterAlive">
        <div style="flex: 1;">
            <span :class="collapseBtnClass" style="cursor: pointer; font-size: 18px" @click="collapse"></span>


            <el-breadcrumb separator="/" style="display: inline-block; margin-left: 10px">
                <el-breadcrumb-item :to="'/'">首页</el-breadcrumb-item>
                <el-breadcrumb-item>{{ currentPathName }}</el-breadcrumb-item>
            </el-breadcrumb>

        </div>

<!--        <router-view v-if="isRouterAlive" />-->

        <div>
            <el-button style="margin-right: 20px; color: rgba(156,156,156,0.8)" type="text" @click="$router.push('')">
                耗材系统
            </el-button>
            <el-button style="margin-right: 5px; color: rgba(0,0,0,0.8)" type="text" @click="$router.push('/front/home')">
                返回前台
            </el-button>

        </div>

        <el-dropdown style="width: 150px; cursor: pointer; text-align: right">
            <div style="display: inline-block">
                <img :src="user.avatarUrl" alt=""
                     style="width: 30px; border-radius: 50%; position: relative; top: 10px; right: 5px">
                <span>{{ user.nickname }}</span><i class="el-icon-arrow-down" style="margin-left: 5px"></i>
            </div>
            <el-dropdown-menu slot="dropdown" style="width: 100px; text-align: center">
                <el-dropdown-item style="font-size: 14px; padding: 5px 0">
                    <i class="fa fa-user"></i>
                    <router-link to="/person">  个人信息</router-link>
                </el-dropdown-item>

<!--                <el-dropdown-item style="font-size: 14px; padding: 5px 0">-->
<!--                    <i class="fa fa-key"></i>-->
<!--                    <router-link to="/password">  修改密码</router-link>-->
<!--                </el-dropdown-item>-->

                <el-dropdown-item style="font-size: 14px; padding: 5px 0">
                    <i class="fa fa-sign-out" @click="logout"></i>
                    <span style="text-decoration: none" @click="logout">  退出账号  </span>
                </el-dropdown-item>
            </el-dropdown-menu>
        </el-dropdown>

    </div>
</template>



<script>
    import router, {resetRouter} from "@/router";

    export default {
        name: "Header",

        // created() {
        //     // 如果不加 window ，则会使用 vue实例的方法，将无法清除定时器
        //     this.timer = window.setTimeout(() => {
        //         // 两种定时器 setInterval（一直执行） setTimeout（只执行一次）
        //         // 要执行的函数
        //         // console.log("112233")
        //         this.logout()
        //     }, 10000)
        // },
        // beforeDestroy() {
        //     window.clearInterval(this.timer)
        //     this.timer = null
        // },

        created() {
            this.lastTime = new Date().getTime(); //网页第一次打开时，记录当前时间
        },

        props: {
            collapseBtnClass: String,
            user: Object,
        },
        computed: {
            currentPathName () {
                return this.$store.state.currentPathName;//需要监听的数据
            }
        },

        data() {
            return {
                lastTime: null, //最后一次点击的时间
                currentTime: null, //当前点击的时间
                timeOut: 30 * 60 * 1000, //设置超时时间： 15分钟
                // timeOut: 30 * 60 * 1000, //设置超时时间： 15分钟
                isRouterAlive: true,

                // user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {}
            }
        },
        methods: {
            handleTime() {
                this.currentTime = new Date().getTime(); //记录这次点击的时间
                if (this.currentTime - this.lastTime > this.timeOut) {
                    //判断上次最后一次点击的时间和这次点击的时间间隔是否大于15分钟
                    //大于15分钟,跳转路由到login页
                    // this.$store.dispatch("user/logout");
                    // this.$router.push("/login");
                    //清空缓存
                    localStorage.removeItem("user")
                    localStorage.removeItem("menus")
                    router.push("/front/home")
                    // 重置路由
                    resetRouter()
                } else {
                    this.lastTime = new Date().getTime(); //如果在15分钟内点击，则把这次点击的时间记录覆盖掉之前存的最后一次点击的时间
                    console.log("移动")
                }
            },

            collapse() {
                // this.$parent.$parent.$parent.$parent.collapse()  // 通过4个 $parent 找到父组件，从而调用其折叠方法
                this.$emit("asideCollapse")
            },

            logout() {
                // this.$router.push("/login")
                // localStorage.removeItem("user")
                this.$store.commit("logout")
                this.$message.success("退出成功")
            },

        }
    }
</script>

<style scoped>
    a{
        text-decoration: none;
        color:#606266 ;
    }
    /*点击之后*/
    .router-link-active{
      text-decoration: none;
      color:#606266;
    }
</style>