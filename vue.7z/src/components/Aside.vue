<template>
<!--    <el-menu :default-openeds="opens" style="min-height: 100%; overflow-x: hidden; border: none;"-->
<!--             background-color="rgb(48, 65, 86)"-->
<!--             text-color="#fff"-->
<!--             active-text-color="#ffd04b"-->
<!--             :collapse-transition="false"-->
<!--             :collapse="isCollapse"-->
<!--             router-->
<!--    >-->
    <el-menu :default-openeds="opens" style="min-height: 100%; overflow-x: hidden; border: none;"
             background-color="#dbdbdb"
             text-color="#545454"
             active-text-color="#2c2c2c"
             :collapse-transition="false"
             :collapse="isCollapse"
             router
    >
        <div style="height: 60px; line-height: 60px; text-align: center">
            <img src="../assets/BZU.png" alt="" style="width: 30px; position: relative; top: 10px; margin-right: 5px">
<!--            <b style="color: rgb(37,135,255)" v-show="logoTextShow" >实验室综合系统</b>-->
            <b style="color: rgba(64,0,0,0.87)" v-show="logoTextShow" >实验室综合系统</b>
        </div>

        <fragment v-for="item in menus" :key="item.id">
            <fragment v-if="item.path">
                <el-menu-item :index="item.path">
                    <i :class="item.icon"></i>
                    <span slot="title">{{ item.name }}</span>
                </el-menu-item>
            </fragment>
            <fragment v-else>
                <el-submenu :index="item.id + ''">
                    <template slot="title">
                        <i :class="item.icon"></i>
                        <span slot="title">{{ item.name }}</span>
                    </template>

                    <fragment  v-for="subItem in item.children" :key="subItem.id">
                        <el-menu-item :index="subItem.path">
                            <template slot="title">
                                <i :class="subItem.icon"></i>
                                <span slot="title">{{ subItem.name }}</span>
                            </template>

                        </el-menu-item>
                    </fragment>
                </el-submenu>
            </fragment>
        </fragment>


    </el-menu>
</template>

<script>
    export default {
        name: "Aside",
        props: {
            isCollapse: Boolean,
            logoTextShow: Boolean,
        },
        data() {
            return {
                menus: localStorage.getItem("menus") ? JSON.parse(localStorage.getItem("menus")) : [],
                opens: localStorage.getItem("menus") ? JSON.parse(localStorage.getItem("menus")).map(v => v.id + '') : []
            }
        },
    }
</script>

<style scoped>

    /*!*解决收缩菜单文字不消失问题*!*/
    /*.el-menu--collapse span {*/
    /*    visibility: hidden;*/
    /*}*/
</style>