import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import './assets/gloable.css'
import request from "@/utils/request";
import store from './store'
import Fragment from 'vue-fragment'
import 'font-awesome/css/font-awesome.min.css'

// main.js全局注册markdown编辑器插件
import mavonEditor from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
// use
Vue.use(mavonEditor)

import VueParticles from 'vue-particles'
Vue.use(VueParticles)

// /*视频插件*/
// import VideoPlayer from 'vue-video-player'
// Vue.use(VideoPlayer);


Vue.config.productionTip = false

Vue.use(ElementUI, { size: "mini" });

Vue.prototype.request=request

Vue.use(Fragment.Plugin)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')