<template>
    <h1>新闻页面</h1>
</template>

<script>
    export default {
        name: "news"
    }
</script>

<style scoped>

</style>