<template>
    <div class="wrapper">
        <el-button type="text" size="medium" style="width: 30px;margin-left: 10px;" autocomplete="off" @click="$router.push('/front/home')">返回前台</el-button>
        <div style="margin: 50px auto; background-color: #fff; width: 350px; height: 340px; padding: 20px; border-radius: 10px">
            <div style="margin: 5px 0; text-align: center; font-size: 24px"><b>登 录</b></div>
            <!-- :model数据绑定，:rules验证规则 -->
            <el-form :model="user" :rules="rules" ref="userForm">
                <el-form-item prop="username">
                    <div style="display: flex">
                        <el-input size="medium" style="margin: 10px 0" prefix-icon="el-icon-user" clearable v-model="user.username"></el-input>
                        <el-button type="text" style="width: 15%;margin-left: 5px" autocomplete="off" @click="$router.push('/register')">注册账号</el-button>
                    </div>

                </el-form-item>
                <el-form-item prop="password">
                    <div style="display: flex">
                        <el-input size="medium" style="margin: 10px 0" prefix-icon="el-icon-lock" show-password clearable v-model="user.password"></el-input>
                        <el-button type="text" style="width: 15%;margin-left: 5px" autocomplete="off" @click="$router.push('/reset')">重置密码</el-button>
                    </div>
                </el-form-item>

                <el-form-item>
                    <div style="display: flex">
                        <el-input size="medium" prefix-icon="el-icon-key" v-model="user.validCode" style="width: 50%;margin: 5px 0;" clearable placeholder="请输入验证码"></el-input>
                        <ValidCode class="code" style="width: 40%;margin-left: 8px;margin-right: 10px"  @input="createValidCode" />
                    </div>
                </el-form-item>
<!--                <el-form-item>-->
<!--                    <el-radio v-model="" :label="1">管理员</el-radio>-->
<!--                    <el-radio v-model="" :label="2">学生</el-radio>-->
<!--                    <el-radio v-model="" :label="3">教师</el-radio>-->
<!--                </el-form-item>-->
                <el-form-item style="margin: 20px 0; text-align: right">
                    <el-button size="medium" type="primary" style="width: 100%" autocomplete="off" @click="login">登 录</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    import {resetRouter, setRoutes} from "@/router";
    import ValidCode from "@/components/ValidCode";

    export default {
        name: "Login",

        components: {
          ValidCode
        },
        data() {
            return {
                user: {},
                rules: {
                    username: [
                        { required: true, message: '请输入用户名', trigger: 'blur' },
                        { min: 3, max: 10, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                        { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
                    ],

                },
                ValidCode: ''
            }
        },
        methods: {
            createValidCode(data) {
              this.validCode = data
            },

            login: function () {
                this.$refs['userForm'].validate((valid) => {
                    if (valid) {  // 表单校验合法

                        if (!this.user.validCode) {
                            this.$message.error("请填写验证码")
                            return
                        }
                        if(this.user.validCode.toLowerCase() !== this.validCode.toLowerCase()) {
                            this.$message.error("验证码错误")
                            return
                        }

                        this.request.post("/user/login", this.user).then(res => {
                            if (res.code === '200') {
                                localStorage.setItem("user", JSON.stringify(res.data))  // 存储用户信息到浏览器
                                localStorage.setItem("menus", JSON.stringify(res.data.menus))

                                //动态设置当前用户路由
                                setRoutes()

                                if(res.data.role === 'ROLE_STUDENT'){
                                    this.$router.push("/front/home")
                                    this.$notify.info({
                                        title: '提示: ',
                                        message: '登录成功',
                                        position: 'bottom-left',
                                        showClose: false
                                    });
                                }else if(res.data.role === 'Guest'){
                                    this.$router.push("/front/home")
                                    this.$notify.info({
                                        title: '提示: ',
                                        message: '登录成功',
                                        position: 'bottom-left',
                                        showClose: false
                                    });
                                }else {
                                    this.$router.push("/")
                                    this.$message.success("登录成功")
                                }
                            } else {
                                this.$message.error(res.msg)
                            }
                        })
                    }
                });
            }
        },
        created() {
            // 按 Enter 键登录系统
            document.onkeydown = (e) => {
                e = window.event || e
                if (this.$route.path === '/login' && e.keyCode === 13) this.login()  // submitLoginForm() 为登录函数
            }
        },

        // created() {
        //     this.$nextTick(() => {
        //         // 禁用右键
        //         // document.oncontextmenu = new Function("event.returnValue=false");
        //         // 禁用选择
        //         document.onselectstart = new Function("event.returnValue=false");
        //     });
        // }
    }
</script>



<style>
    .code {
        moz-user-select: -moz-none;
        -moz-user-select: none;
        -o-user-select: none;
        -khtml-user-select: none;
        -webkit-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    /*.wrapper{*/
    /*    background-image: url("../assets/t01e2fa7120d00d62da.jpg");*/
    /*    overflow: hidden;*/
    /*    background-size:cover;*/
    /*    height: 300%;*/
    /*    margin-left: 0px;*/
    /*    margin-bottom: -500px;*/
    /*}*/
    .wrapper {
        height: 100vh;
        background-image: linear-gradient(to bottom right, #ffa165, #5673ff);
        overflow: hidden;
    }
</style>
