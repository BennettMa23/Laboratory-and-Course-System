<template>
  <div >
<!--    头部-->
    <div style="display: flex; height: 60px; line-height: 60px; border-bottom: 1px solid #eee;">
      <div style="width: 300px; display: flex; padding-left: 30px">
        <div style="width: 60px">
          <img src="../../assets/BZU.png" alt="" style="width: 45px; position: relative; top: 7px; right: 0">
        </div>
        <div style="flex: 1;font-size: 17px;">实验室综合系统</div>
      </div>
      <div style="flex: 1;">

        <el-menu :default-active="'1'" class="el-menu-demo" mode="horizontal" style="text-align: center;font-weight: bold;" router>

          <el-menu-item style="margin-left: 180px;font-size: 15px;" index="/front/home" >首页</el-menu-item>
          <el-menu-item style="margin-left: 30px;font-size: 15px;" index="/front/video">视频列表</el-menu-item>
          <el-menu-item style="margin-left: 30px;font-size: 15px;" index="/front/article">制度准则</el-menu-item>
          <el-menu-item style="margin-left: 30px;font-size: 15px;" @click="hrefClick">学校官网</el-menu-item>
<!--          <el-menu-item style="margin-left: 30px" >耗材系统</el-menu-item>-->
          <el-menu-item style="margin-left: 30px;margin-right: 200px;font-size: 15px;" v-if="user.role === 'ROLE_ADMIN' || user.role === 'ROLE_TEACHER' || user.role === 'ROLE_STUDENT'"  index="/home">操作中心</el-menu-item>


        </el-menu>
      </div>
      <div style="width: 200px" >
<!--        <el-button style="margin-right: 5px; color: #cf9236" type="text" @click="$router.push('/home')">-->
<!--          后台-->
<!--        </el-button>-->

        <div v-if="!user.username" style="text-align: right; padding-right: 30px">
          <el-button @click="$router.push('/login')">登录</el-button>
          <el-button @click="$router.push('/register')">注册</el-button>
        </div>
        <div v-else>
          <el-dropdown style="width: 150px; cursor: pointer; text-align: right">
            <div style="display: inline-block">
              <img :src="user.avatarUrl" alt=""
                   style="width: 30px; border-radius: 50%; position: relative; top: 10px; right: 5px">
              <span>{{ user.nickname }}</span><i class="el-icon-arrow-down" style="margin-left: 5px"></i>
            </div>
            <el-dropdown-menu slot="dropdown" style="width: 100px; text-align: center">
<!--              <el-dropdown-item style="font-size: 14px; padding: 5px 0" v-if="user.role !== 'Guest'">-->
<!--                <router-link to="/home">进入后台</router-link>-->
<!--              </el-dropdown-item>-->
              <el-dropdown-item style="font-size: 14px; padding: 5px 0">
                <router-link to="/front/person">个人信息</router-link>
              </el-dropdown-item>
              <el-dropdown-item style="font-size: 14px; padding: 5px 0">
                <router-link to="/front/password">修改密码</router-link>
              </el-dropdown-item>

              <el-dropdown-item style="font-size: 14px; padding: 5px 0">
                <span style="text-decoration: none" @click="logout">退出</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>

    <div style="width: 1000px; margin: 0 auto">
<!--      路由其他页面-->
      <router-view />
    </div>

  </div>
</template>

<script>
  import router, {resetRouter} from "@/router";

export default {
  name: "Front",
  data() {
    return {
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {}
    }
  },
  created() {

  },
  methods: {
    logout() {
      // this.$store.commit("logout")
      //清空缓存
      localStorage.removeItem("user")
      localStorage.removeItem("menus")
      // router.push("/login")
      // 重置路由
      resetRouter()
      window.parent.location.reload(true)//刷新页面
      // this.$router.push("/front/home")
      this.$message.success("退出成功")
    },
    hrefClick(){
      window.location.href="https://www.bzu.edu.cn/";//当前标签页
      // window.open("https://www.bzu.edu.cn/");//打开一个新的标签页
    }
  }
}
</script>

<style>
    .item{
      display: inline-block;
      width: 100px;
      text-align: center;
      cursor: pointer
    }
    .item a {
      color: 	#1E90FF;
    }
    .item:hover{
      background-color: 	LightPink;
    }
    .col{
        color: #284c80;
    }
</style>
