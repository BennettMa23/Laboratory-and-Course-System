<template>
  <div>
    <div style="margin: 10px 0 ">
      <el-carousel height="300px" :interval="10000">
        <el-carousel-item v-for="item in imgs" :key="item">
          <img :src="item" alt="" style="width: 100%">
        </el-carousel-item>
      </el-carousel>
    </div>

    <div style="margin: 30px 0; border-bottom: 2px dashed #1782ff"></div>

    <div style="margin: 30px 0;">
      <h2 style="text-align: center">学校简介</h2>
      <p class="p">
        滨州学院是一所省属全日制普通本科院校，坐落在兵圣孙子故里、渤海革命老区、美丽富饶的黄河三角洲中心城市——滨州市。前身是始建于1954年的北镇师范学校，
        1983年更名为滨州师范专科学校，2004年经教育部批准改建为滨州学院。2012年顺利通过教育部本科教学工作合格评估，2018年10月顺利接受教育部本科教学工作审核评估，
        2021年1月获批山东省应用型本科高校建设首批支持高校，2021年10月获批硕士学位授予单位。
      </p>
      <p class="p">
        学校校园占地面积131.3万㎡，校舍建筑面积72.2万㎡，其中实验室面积9.6万㎡。设有21个实验教学中心，其中2个为省级实验教学示范中心；教学科研仪器设备总值2.7亿元，
        图书馆纸质图书192.5万册，电子图书121.5万册。设有19个二级学院，61个本科专业、30个专科专业，面向全国30个省（市、自治区）招生，全日制本专科在校生18841人。
      </p>
      <p class="p">
        学校坚持以人为本，依法治校，持续提升治理能力和治理水平，不断加强党建和思想政治教育工作，致力于绿色、文明、平安、和谐、美丽校园建设，取得了显著成绩。
        先后获得“全国法制宣传教育先进单位”“全国绿化模范单位”“全国高校学生公寓管理服务工作先进单位”“平安山东建设先进单位”“山东省高校平安校园”等40多项省级及以上荣誉称号；
        《中国教育报》《中国经济导报》《中国民航报》《中国航空报》《大众日报》《高教领导参考》、光明网、大众网等媒体多次对学校改革发展情况进行报道，学校影响力和美誉度进一步提升。
      </p>
      <p class="p">
        进入新时代，开启新征程。学校党委、行政正团结带领全校师生员工，坚持以习近平新时代中国特色社会主义思想为指导，深入学习贯彻全国全省教育大会精神，紧紧抓住“黄河流域生态保护和高质量发展”重大国家战略、
        “交通强国”国家战略以及山东省新旧动能转换、推进新时代高等教育高质量发展的重大机遇，弘扬“自强不息、守正出奇”的学校精神，秉承“明德、砺学、日新、致远”的校训，不忘初心、牢记使命，改革创新、攻坚克难，
        走特色发展、高质量发展、卓越发展之路，为加快建成航空特色鲜明的高水平应用型大学而不懈奋斗。
      </p>

    </div>

    <div style="margin: 30px 0; border-bottom: 2px dashed #1782ff"></div>

    <div>
      <el-row :gutter="10">
        <el-col :span="6" a="0" v-for="item in files" :key="item.id" style="margin-bottom: 10px;">
          <div style=" padding-bottom: 10px;height: 110px">
            <img  :src="item.url" style="width: 100%;height: 110px">
          </div>
        </el-col>
      </el-row>
    </div>


  </div>
</template>

<script>
export default {
  name: "FrontHome",
  data() {
    return {
      imgs: [
          'https://www.bzu.edu.cn/_upload/article/images/4e/36/1628542440e3a97775b5ede11014/03796251-3165-4931-8baa-66d85bbf179d.jpg',
          'https://www.bzu.edu.cn/_upload/article/images/b1/4a/3c5faa274fb0a9fc85f7f2863652/ed2b9ab8-f603-4f5b-9382-7978d51d5f32.jpg',
          'https://www.bzu.edu.cn/_upload/article/images/bb/9e/5cabfeb24784b1b7b042aeef0c86/85b9b801-00bb-4b52-936e-571e8c95e734.jpg',
          'https://www.bzu.edu.cn/_upload/article/images/75/ea/cba8178e4ee98e0d1ba44367a406/cda45eda-c75d-4159-9b0f-0ef2c2b6b18c.jpg',
          // 'https://www.bzu.edu.cn/_upload/article/images/82/d6/c6791e4741a6a4adf33317f0c0c5/99e152db-df45-4af1-9563-7b89c86b42d2.jpg'
      ],
      files: [],
    }
  },
  created() {
    this.request.get("/echarts/file/front/all").then(res => {
      console.log(res.data)
      this.files = res.data.filter(v => v.type === 'png' || v.type === 'jpg' || v.type === 'webp')
    })
  },
  methods: {

  }
}
</script>

<style>
  .p{
    /*color: #1E90FF;*/
    margin-top: 10px;
    text-indent:2em;
    /*font-weight: bold;*/
    font-size: 20px;
    line-height: 150%;
  }

</style>
