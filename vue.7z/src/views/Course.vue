<template>
  <div>
    <div style="margin: 10px 0">
      <el-input style="width: 200px" placeholder="请输入课程名" suffix-icon="el-icon-search" v-model="coursename"></el-input>
      <el-input style="width: 200px;margin-left: 5px" placeholder="请输入老师名" suffix-icon="el-icon-search" v-model="teachername"></el-input>
      <el-input style="width: 200px;margin-left: 5px" placeholder="请输入班级名" suffix-icon="el-icon-search" v-model="classname"></el-input>
      <el-button class="ml-5" type="primary" @click="load">搜索</el-button>
      <el-button type="warning" @click="reset">重置</el-button>
    </div>
    <div style="margin: 10px 0">
      <el-button type="primary" @click="handleAdd" v-if="user.role !== 'ROLE_STUDENT'">新增 <i class="el-icon-circle-plus-outline"></i></el-button>
      <el-popconfirm
          class="ml-5"
          confirm-button-text='确定'
          cancel-button-text='我再想想'
          icon="el-icon-info"
          icon-color="red"
          title="您确定批量删除这些数据吗？"
          @confirm="delBatch"

      >
        <el-button type="danger" slot="reference" v-if="user.role === 'ROLE_ADMIN'">批量删除 <i class="el-icon-remove-outline"></i></el-button>
      </el-popconfirm>
      <el-button type="primary" @click="exp" class="ml-5" v-if="user.role !== 'ROLE_STUDENT'">课程下载 <i class="el-icon-bottom"></i></el-button>


    </div>
    <el-table :data="tableData" border stripe :header-cell-class-name="'headerBg'" :row-class-name="tableSe"
              @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="50"></el-table-column>
      <el-table-column prop="number" label="课程号" width="90" sortable></el-table-column>
      <el-table-column prop="coursename" label="课程名称" sortable></el-table-column>
      <el-table-column prop="teachername" label="授课老师"  width="90"></el-table-column>
      <el-table-column prop="attributes" label="属性" width="70" sortable></el-table-column>
      <el-table-column prop="exam" label="考试" width="50"></el-table-column>
      <el-table-column prop="hours" label="学时" width="50"></el-table-column>
      <el-table-column prop="credit" label="学分" width="50"></el-table-column>
      <el-table-column prop="classroom" label="教室" width="130"></el-table-column>
      <el-table-column prop="classname" label="班级" ></el-table-column>
      <el-table-column prop="selection" label="已选" width="50"></el-table-column>
      <el-table-column prop="weeks" label="周次" width="80"></el-table-column>
<!--      <el-table-column label="启用">-->
<!--        <template slot-scope="scope">-->
<!--          <el-switch v-model="scope.row.state" active-color="#13ce66" inactive-color="#ccc"-->
<!--                     @change="changeEnable(scope.row)"></el-switch>-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="操作" width="280" align="center">
        <template slot-scope="scope">

          <el-button type="success" @click="handleEdit(scope.row)" v-if="user.role !== 'ROLE_STUDENT'">编辑 <i class="el-icon-edit"></i></el-button>
          <el-popconfirm
              class="ml-5"
              confirm-button-text='确定'
              cancel-button-text='我再想想'
              icon="el-icon-info"
              icon-color="red"
              title="您确定删除吗？"
              @confirm="del(scope.row.id)"
          >
            <el-button type="danger" slot="reference" v-if="user.role === 'ROLE_ADMIN'">删除 <i class="el-icon-remove-outline"></i></el-button>
          </el-popconfirm>

          <el-popconfirm
                  v-if="user.role === 'ROLE_STUDENT' && scope.row.userid === null && scope.row.attributes === '任选'"
                  confirm-button-text='确定'
                  cancel-button-text='我再想想'
                  icon="el-icon-info"
                  icon-color="red"
                  title="您确定选课吗？"
                  @confirm="selCourse(scope.row.id)"
          >
            <el-button v-if="scope.row.selection < scope.row.capacity" type="primary" slot="reference" >选课 </el-button>
          </el-popconfirm>

          <el-popconfirm
                  v-if="user.role === 'ROLE_STUDENT' && scope.row.userid === String(user.id) && scope.row.attributes === '任选'"
                  confirm-button-text='确定'
                  cancel-button-text='我再想想'
                  icon="el-icon-info"
                  icon-color="red"
                  title="您确定退课吗？"
                  @confirm="dropCourse(scope.row.id)"
          >
            <el-button type="danger" slot="reference"  >退课 </el-button>
          </el-popconfirm>


          <el-button slot="reference" v-if="scope.row.attributes !== '任选' && user.role === 'ROLE_STUDENT'" >不可自选课 </el-button>

        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[2, 5, 10, 20,500]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

    <el-dialog title="课程信息" :visible.sync="dialogFormVisible" width="30%" >
      <el-form label-width="80px" size="small">
        <el-form-item label="课程号">
          <el-input v-model="form.number" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程名称">
          <el-input v-model="form.coursename" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="授课老师">
          <el-input v-model="form.teachername" autocomplete="off"></el-input>
        </el-form-item>
<!--        <el-form-item label="考试方式">-->
<!--          <el-input v-model="form.exam" autocomplete="off"></el-input>-->
<!--        </el-form-item>-->

        <el-form-item label="考试方式">
          <el-select v-model="form.exam" placeholder="请选择考试方式" style="width: 100%">
            <el-option label="考试" value="考试"></el-option>
            <el-option label="考查" value="考查"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="学时">
          <el-input v-model="form.hours" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="学分">
          <el-input v-model="form.credit" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="教室">
          <el-input v-model="form.classroom" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="课程属性">
          <el-select v-model="form.attributes" placeholder="请选择课程属性" style="width: 100%">
            <el-option label="必修" value="必修"></el-option>
            <el-option label="任选" value="任选"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="课容量">
          <el-input v-model="form.capacity" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="面向班级">
          <el-input v-model="form.classname" autocomplete="off"></el-input>
        </el-form-item>
<!--        <el-form-item label="老师">-->
<!--          <el-select clearable v-model="form.teacherId" placeholder="请选择">-->
<!--            <el-option v-for="item in teachers" :key="item.id" :label="item.nickname" :value="item.id"></el-option>-->
<!--          </el-select>-->
<!--        </el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>

import {serverIp} from "../../public/config";

export default {
  name: "Course",
  data() {
    return {
      form: {},
      tableData: [],
      coursename: '',
      teachername: '',
      classname: '',
      multipleSelection: [],
      pageNum: 1,
      pageSize: 10,
      total: 0,
      dialogFormVisible: false,
      teachers: [],
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},
      localcourse: localStorage.getItem("course") ? JSON.parse(localStorage.getItem("course")) : {},

    }
  },
  created() {
    this.load()
  },
  methods: {
    // selectCourse(courseId) {
    //   this.request.post('/course/studentCourse/' + courseId + "/" + this.user.id).then(res => {
    //     if (res.code === '200') {
    //       this.$message.success("选课成功")
    //
    //     } else {
    //       this.$message.success(res.msg)
    //     }
    //   })
    // },
    load() {
      this.request.get("/course/page", {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          coursename: this.coursename,
          classname: this.classname,
          teachername: this.teachername,
        }
      }).then(res => {

        this.tableData = res.data.records
        this.total = res.data.total

      })

      // this.request.get("/teachers").then(res => {
      //   this.teachers = res.data.coursename
      // })
    },
    changeEnable(row) {
      this.request.post("/course/update", row).then(res => {
        if (res.code === '200') {
          this.$message.success("操作成功")
        }
      })
    },
    handleAdd() {
      this.dialogFormVisible = true
      this.form = {}
    },
    handleEdit(row) {
      this.form = JSON.parse(JSON.stringify(row))
      this.dialogFormVisible = true
    },
    del(id) {
      this.request.delete("/course/" + id).then(res => {
        if (res.code === '200') {
          this.$message.success("删除成功")
          this.load()
        } else {
          this.$message.error("删除失败")
        }
      })
    },
    handleSelectionChange(val) {
      console.log(val)
      this.multipleSelection = val
    },
    delBatch() {
      let ids = this.multipleSelection.map(v => v.id)  // [{}, {}, {}] => [1,2,3]
      this.request.post("/course/del/batch", ids).then(res => {
        if (res.code === '200') {
          this.$message.success("批量删除成功")
          this.load()
        } else {
          this.$message.error("批量删除失败")
        }
      })
    },
    save() {
      this.request.post("/course", this.form).then(res => {
        if (res.code === '200') {
          this.$message.success("保存成功")
          this.dialogFormVisible = false
          this.load()
        } else {
          this.$message.error("保存失败")
        }
      })
    },
    reset() {
      this.coursename = ""
      this.teachername = ""
      this.classname = ""
      this.load()
    },
    handleSizeChange(pageSize) {
      console.log(pageSize)
      this.pageSize = pageSize
      this.load()
    },
    handleCurrentChange(pageNum) {
      console.log(pageNum)
      this.pageNum = pageNum
      this.load()
    },
    // download(url) {
    //   window.open(url)
    // },
    exp() {
      window.open(`http://${serverIp}:9090/course/export`)
    },

    selCourse(courseId) {
      this.request.post('/course/selectcourse/' + courseId + "/" + this.user.id).then(res => {
        if (res.code === '200') {
          this.$message.success("选课成功")
          window.parent.location.reload(true)//刷新页面

        } else {
          this.$message.success(res.msg)
        }
      })
      // console.log(this.user.id)
      // console.log(courseId)
    },

    dropCourse(courseId) {
      // console.log(courseId)
      this.request.post('/course/dropcourse/' + courseId + "/" + this.user.id).then(res => {
        if (res.code === '200') {
          this.$message.success("退课成功")
          window.parent.location.reload(true)//刷新页面
        } else {
          this.$message.success(res.msg)
        }
      })
      // console.log(this.user.id)
      // console.log(courseId)
    },

    // eslint-disable-next-line no-unused-vars
    tableSe({ row }) {
      if (row.attributes == '任选'){
        if (row.selection >= row.capacity) {
          console.log(row)
          return 'rowse';
        }
      }
      return '';
    },
  }
}
</script>

<style>

  .el-table .rowse {
    background-color: rgba(255, 192, 0, 0.64) !important;
  }
</style>
