<template>
    <div>
        <div>
            <div style="padding-bottom: 30px;">
                <b>欢迎你！{{ user.nickname }}</b>
<!--                <b>欢迎你！{{ user }}</b>-->

                <div style="color: #666;font-size: 15px; text-align: center" v-if="user.role === 'ROLE_TEACHER'">
                    这是您的实验课表
                </div>

                <div style="color: #666;font-size: 15px; text-align: center" v-if="user.role === 'ROLE_STUDENT'">
                    这是系统导入的实验课表
                </div>
                <div style="color: #666;font-size: 15px; text-align: center" v-if="user.role === 'ROLE_ADMIN'">
                    这是全部的课表
                </div>
            </div>



            <el-table :data="tableData" border stripe :header-cell-class-name="'headerBg'"
                      @selection-change="handleSelectionChange" >

                <el-table-column prop="number" label="课程号" width="100" sortable></el-table-column>
                <el-table-column prop="coursename" label="课程名" width="240" sortable></el-table-column>
                <el-table-column prop="teachername" label="教师" width="100" sortable></el-table-column>
                <el-table-column prop="classname" label="班级" width="240" sortable></el-table-column>
                <el-table-column prop="classroom" label="教室" sortable></el-table-column>
                <el-table-column prop="hours" label="总学时" sortable></el-table-column>
                <el-table-column prop="credit" label="学分" sortable></el-table-column>
                <el-table-column prop="weeks" label="上课周次"></el-table-column>


            </el-table>

            <el-button v-if="user.role === 'ROLE_STUDENT'" style="padding-left: 1160px;padding-top: 10px;
            font-size: 14px; color: rgba(23,86,255,0.88)" type="text"  @click="dialogTableVisible = true">
                查看自主选修课程
            </el-button>

            <div style="padding: 10px 0">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="pageNum"
                        :page-sizes="[10, 20, 50]"
                        :page-size="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                </el-pagination>
            </div>


            <el-dialog title="自主选修课程" :visible.sync="dialogTableVisible">
                <el-table :data="elective_course">
                    <el-table-column prop="number" label="课程号" width="100" sortable></el-table-column>
                    <el-table-column prop="coursename" label="课程名" width="180" sortable></el-table-column>
                    <el-table-column prop="teachername" label="教师" width="100" sortable></el-table-column>
                    <el-table-column prop="classroom" label="实验室" width="150" sortable></el-table-column>
                    <el-table-column prop="hours" label="总学时" sortable></el-table-column>
                    <el-table-column prop="credit" label="学分" sortable></el-table-column>
                </el-table>
            </el-dialog>


        </div>
    </div>

</template>



<script>

    export default {
        name: "Home",
        data() {
            return {
                form: {},
                tableData: [],
                name: '',
                classname: '',
                teaname: '',
                userid: '',
                cou: {},
                edu: {},

                multipleSelection: [],
                pageNum: 1,
                pageSize: 10,
                total: 0,
                dialogFormVisible: false,
                teachers: [],
                user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},

                elective_course: [],
                dialogTableVisible: false,
            }
        },
        created() {

            this.getEdu()
            this.electiveCourse()

        },

        methods: {

            getEdu: function () {
                if (this.user.role === 'ROLE_STUDENT') {
                    this.request.get("/students/findone/", {
                        params: {id: this.user.id}
                    }).then(res => {
                        this.classname = res.data.classname
                        // localStorage.setItem("course", JSON.stringify(res.data.classname))
                        this.getCou()
                    })
                }
                if (this.user.role === 'ROLE_TEACHER') {
                    this.request.get("/teachers/findone/", {
                        params: {id: this.user.id}
                    }).then(res => {
                        this.teaname = res.data.name
                        // localStorage.setItem("classname", JSON.stringify(res.classname))
                        this.getCou()
                    })
                }
                if (this.user.role === 'ROLE_ADMIN') {
                    this.getCou()
                }

            },

            getCou() {
                // debugger
                if (this.user.role === 'ROLE_STUDENT'){
                    this.request.get("/course/page", {
                        params: {
                            pageNum: this.pageNum,
                            pageSize: this.pageSize,
                            classname: this.classname,
                        }
                    }).then(res => {
                        this.tableData = res.data.records
                        localStorage.setItem("course", JSON.stringify(res.data.records))
                        this.total = res.data.total
                    })
                }
                if (this.user.role === 'ROLE_TEACHER'){
                    this.request.get("/course/page", {
                        params: {
                            pageNum: this.pageNum,
                            pageSize: this.pageSize,
                            teachername: this.teaname,
                        }
                    }).then(res => {
                        this.tableData = res.data.records
                        this.total = res.data.total
                    })
                }
                if (this.user.role === 'ROLE_ADMIN'){
                    this.request.get("/course/page", {
                        params: {
                            pageNum: this.pageNum,
                            pageSize: this.pageSize,

                        }
                    }).then(res => {
                        this.tableData = res.data.records
                        this.total = res.data.total
                    })
                }
            },

            handleSelectionChange(val) {
                console.log(val)
                this.multipleSelection = val
            },

            reset() {
                this.name = ""
                this.getEdu()
                // this.getCou()
            },
            handleSizeChange(pageSize) {
                console.log(pageSize)
                this.pageSize = pageSize
                this.getEdu()
                // this.getCou()
            },
            handleCurrentChange(pageNum) {
                console.log(pageNum)
                this.pageNum = pageNum
                this.getEdu()
                // this.getCou()
            },
            electiveCourse() {
                console.log(123)
                this.request.get("/course/selcoursepage", {
                    params: {
                        userid: this.user.id,
                    }
                }).then(res => {
                    this.elective_course = res.data.records

                })
            },

        }
    }
</script>

<style scoped>

</style>
