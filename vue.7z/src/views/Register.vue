<template>
    <div class="wrapper">
        <el-button type="text" size="medium" style="width: 30px;margin-left: 10px;" autocomplete="off" @click="$router.push('/front/home')">返回前台</el-button>
        <div style="margin: 50px auto; background-color: #fff; width: 350px; height: 500px; padding: 20px; border-radius: 10px">
            <div style="margin: 5px 0; text-align: center; font-size: 24px"><b>注 册</b></div>
            <el-form :model="user" :rules="rules" ref="userForm">
                <el-form-item prop="username">
                    <el-input placeholder="请输入账号" size="medium" style="margin: 5px 0" prefix-icon="el-icon-user" v-model="user.username"></el-input>
                </el-form-item>
                <el-form-item prop="nickname">
                    <el-input placeholder="请输入昵称" size="medium" style="margin: 5px 0" prefix-icon="el-icon-user-solid" v-model="user.nickname"></el-input>
                </el-form-item>

                <el-form-item size="medium">
                    <el-select v-model="user.role" placeholder="请选择角色" style="width: 100%">
                        <el-option label="访客" value="Guest"></el-option>
                        <el-option label="教师" value="ROLE_TEACHER"></el-option>
                        <el-option label="学生" value="ROLE_STUDENT"></el-option>
<!--                        <el-option label="管理员" value="ROLE_ADMIN"></el-option>-->
                    </el-select>
                </el-form-item>

                <el-form-item prop="id" v-if="user.role !== 'Guest'">
                    <el-input placeholder="请绑定学校ID,访客不需要绑定" size="medium" style="margin: 5px 0" prefix-icon="el-icon-link" v-model="user.id"></el-input>
                </el-form-item>


                <el-form-item prop="password">
                    <el-input placeholder="请输入密码" size="medium" style="margin: 5px 0" prefix-icon="el-icon-lock" show-password v-model="user.password"></el-input>
                </el-form-item>
                <el-form-item prop="confirmPassword">
                    <el-input placeholder="请确认密码" size="medium" style="margin: 5px 0" prefix-icon="el-icon-lock" show-password v-model="user.confirmPassword"></el-input>
                </el-form-item>
                <el-form-item style="margin: 5px 0; text-align: right">
                    <el-button type="warning" size="medium"  style="width: 45%;margin-right: 20px" autocomplete="off" @click="$router.push('/login')">返回登录</el-button>
                    <el-button type="primary" size="medium"  style="width: 45%;margin-left: 10px" autocomplete="off" @click="login">注 册</el-button>
                </el-form-item>
            </el-form>
        </div>

<!--        <div class="login">-->
<!--            <vue-particles-->
<!--                    class="login-bg"-->
<!--                    color="#39AFFD"-->
<!--                    :particleOpacity="0.7"-->
<!--                    :particlesNumber="100"-->
<!--                    shapeType="circle"-->
<!--                    :particleSize="4"-->
<!--                    linesColor="#8DD1FE"-->
<!--                    :linesWidth="1"-->
<!--                    :lineLinked="true"-->
<!--                    :lineOpacity="0.4"-->
<!--                    :linesDistance="150"-->
<!--                    :moveSpeed="3"-->
<!--                    :hoverEffect="true"-->
<!--                    hoverMode="grab"-->
<!--                    :clickEffect="true"-->
<!--                    clickMode="push"-->
<!--            >-->
<!--            </vue-particles>-->
<!--        </div>-->


    </div>
</template>

<script>
    export default {
        name: "Register",
        data() {
            return {
                user: {},
                rules: {
                    username: [
                        { required: true, message: '请输入用户名', trigger: 'blur' },
                        { min: 3, max: 10, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                        { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
                    ],
                    confirmPassword: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                        { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
                    ],
                }
            }
        },
        methods: {
            login() {
                this.$refs['userForm'].validate((valid) => {
                    if (valid) {  // 表单校验合法
                        if (this.user.password !== this.user.confirmPassword) {
                            this.$message.error("两次输入的密码不一致")
                            return false
                        }
                        this.request.post("/user/register", this.user).then(res => {
                            if(res.code === '200') {
                                this.$message.success("注册成功")
                                this.$router.push("/login")
                            } else {
                                this.$message.error(res.msg)
                            }
                        })
                    }
                });
            }
        }
    }
</script>

<style>
    .wrapper {
        height: 100vh;
        background-image: linear-gradient(to bottom right, #ffa165, #5673ff);
        overflow: hidden;
    }
    /*.wrapper {*/
    /*    height: 100vh;*/
    /*    background-image: linear-gradient(to bottom right, #FC466B , #3F5EFB);*/
    /*    overflow: hidden;*/
    /*}*/
</style>
