<template>
  <div>
    <div style="margin: 10px 0">
<!--      <el-input style="width: 200px;margin-left: 5px" placeholder="请输入老师名" suffix-icon="el-icon-search" v-model="teachername"></el-input>-->
      <el-input style="width: 200px;margin-left: 5px" placeholder="请输入课程名" suffix-icon="el-icon-search" v-model="coursename"></el-input>
      <el-button class="ml-5" type="primary" @click="load">搜索</el-button>
      <el-button type="warning" @click="reset">重置</el-button>
    </div>
    <div style="margin: 10px 0">
      <el-button type="primary" @click="handleAdd" v-if="user.role !== 'ROLE_STUDENT'">新增 <i class="el-icon-circle-plus-outline"></i></el-button>
      <el-popconfirm
          class="ml-5"
          confirm-button-text='确定'
          cancel-button-text='我再想想'
          icon="el-icon-info"
          icon-color="red"
          title="您确定批量删除这些数据吗？"
          @confirm="delBatch"

      >
        <el-button type="danger" slot="reference" v-if="user.role === 'ROLE_ADMIN'">批量删除 <i class="el-icon-remove-outline"></i></el-button>
      </el-popconfirm>
      <el-button type="primary" @click="exp" class="ml-5" v-if="user.role !== 'ROLE_STUDENT'">导出 <i class="el-icon-top"></i></el-button>
      <el-popconfirm
              class="ml-5"
              confirm-button-text='确定'
              cancel-button-text='我再想想'
              icon="el-icon-info"
              icon-color="red"
              title="请确保相关文件已上传！"
              @confirm="handleExcelImportSuccess"
      >
        <el-button slot="reference">文件导入数据库 <i class="el-icon-bottom"></i></el-button>
      </el-popconfirm>


    </div>
    <el-table :data="tableData" border stripe :header-cell-class-name="'headerBg'"
              @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="50"></el-table-column>
      <el-table-column prop="profession" label="开课专业" sortable width="110"></el-table-column>
      <el-table-column prop="number" label="课程号" width="80"></el-table-column>
      <el-table-column prop="coursename" label="实验课程名称" sortable width="220"></el-table-column>
      <el-table-column prop="experimental" label="总学时" width="80"></el-table-column>
      <el-table-column prop="projectnum" label="实验项目数" width="120"></el-table-column>
      <el-table-column prop="partprojectnum" label="综合设计性实验项目数"></el-table-column>
      <el-table-column prop="classname" label="班级" width="150"></el-table-column>
      <el-table-column prop="man" label="人数" width="60"></el-table-column>

      <el-table-column label="操作" width="280" align="center">
        <template slot-scope="scope">

          <el-button type="success" @click="handleEdit(scope.row)" v-if="user.role !== 'ROLE_STUDENT'">编辑 <i class="el-icon-edit"></i></el-button>
          <el-popconfirm
              class="ml-5"
              confirm-button-text='确定'
              cancel-button-text='我再想想'
              icon="el-icon-info"
              icon-color="red"
              title="您确定删除吗？"
              @confirm="del(scope.row.id)"
          >
            <el-button type="danger" slot="reference" v-if="user.role === 'ROLE_ADMIN'">删除 <i class="el-icon-remove-outline"></i></el-button>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <div style="padding: 10px 0">
      <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="pageNum"
          :page-sizes="[2, 5, 10, 20,500]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total">
      </el-pagination>
    </div>

    <el-dialog title="教学任务一览表" :visible.sync="dialogFormVisible" width="30%" >
      <el-form label-width="120px" size="small">
        <el-form-item label="开课专业">
          <el-input v-model="form.profession" autocomplete="off"></el-input>
        </el-form-item>

        <el-form-item label="课程号">
          <el-input v-model="form.number" sortable autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="实验课程名称">
          <el-input v-model="form.coursename" sortable autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="是否独立开课">
          <el-input v-model="form.yesno" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="实验总学时">
          <el-input v-model="form.experimental" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="实验项目数">
          <el-input v-model="form.projectnum" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="综合设计性实验项目数">
          <el-input v-model="form.partprojectnum" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="年级、班级">
          <el-input v-model="form.classname" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="本科/专科">
          <el-input v-model="form.edu" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="人数">
          <el-input v-model="form.man" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="实验重复次数">
          <el-input v-model="form.repeatnum" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="实验分组学生数">
          <el-input v-model="form.groups" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="开课单位">
          <el-input v-model="form.danwei" autocomplete="off"></el-input>
        </el-form-item>
<!--        <el-form-item label="老师">-->
<!--          <el-select clearable v-model="form.teacherId" placeholder="请选择">-->
<!--            <el-option v-for="item in teachers" :key="item.id" :label="item.nickname" :value="item.id"></el-option>-->
<!--          </el-select>-->
<!--        </el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>

import {serverIp} from "../../public/config";

export default {
  name: "Task",
  data() {
    return {
      form: {},
      tableData: [],
      coursename: '',
      // teachername: '',
      // classname: '',
      multipleSelection: [],
      pageNum: 1,
      pageSize: 10,
      total: 0,
      dialogFormVisible: false,
      teachers: [],
      user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},

    }
  },
  created() {
    this.load()
  },
  methods: {

    load() {
      this.request.get("/task/page", {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          coursename: this.coursename,

        }
      }).then(res => {

        this.tableData = res.data.records
        this.total = res.data.total

      })

      // this.request.get("/teachers").then(res => {
      //   this.teachers = res.data.coursename
      // })
    },
    changeEnable(row) {
      this.request.post("/task/update", row).then(res => {
        if (res.code === '200') {
          this.$message.success("操作成功")
        }
      })
    },
    handleAdd() {
      this.dialogFormVisible = true
      this.form = {}
    },
    handleEdit(row) {
      this.form = JSON.parse(JSON.stringify(row))
      this.dialogFormVisible = true
    },
    del(id) {
      this.request.delete("/task/" + id).then(res => {
        if (res.code === '200') {
          this.$message.success("删除成功")
          this.load()
        } else {
          this.$message.error("删除失败")
        }
      })
    },
    handleSelectionChange(val) {
      console.log(val)
      this.multipleSelection = val
    },
    delBatch() {
      let ids = this.multipleSelection.map(v => v.id)  // [{}, {}, {}] => [1,2,3]
      this.request.post("/task/del/batch", ids).then(res => {
        if (res.code === '200') {
          this.$message.success("批量删除成功")
          this.load()
        } else {
          this.$message.error("批量删除失败")
        }
      })
    },
    save() {
      this.request.post("/task", this.form).then(res => {
        if (res.code === '200') {
          this.$message.success("保存成功")
          this.dialogFormVisible = false
          this.load()
        } else {
          this.$message.error("保存失败")
        }
      })
    },
    reset() {
      this.coursename = ""
      this.load()
    },
    handleSizeChange(pageSize) {
      console.log(pageSize)
      this.pageSize = pageSize
      this.load()
    },
    handleCurrentChange(pageNum) {
      console.log(pageNum)
      this.pageNum = pageNum
      this.load()
    },
    // download(url) {
    //   window.open(url)
    // },
    exp() {
      window.open(`http://${serverIp}:9090/task/export`)
    },
    handleExcelImportSuccess() {
      this.$message.warning("导入中请等待...")
      this.request.get("/task/in").then(res => {
        if (res.code === '200') {
          this.$message.success("操作成功")
          this.load()
        }else {
          this.$message.error("失败")
        }
      })

    },
  }
}
</script>

<style scoped>

</style>
