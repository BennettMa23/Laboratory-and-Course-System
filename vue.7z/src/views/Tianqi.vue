<template>
<!--  <h1>123</h1>-->
  <div id="he-plugin-simple"></div>
</template>

<script>
  export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name: 'tianqi',
    mounted () {
      window.WIDGET = {
        "CONFIG": {
          "modules": "01234",
          "background": "5",
          "tmpColor": "000000",
          "tmpSize": "16",
          "cityColor": "000000",
          "citySize": "16",
          "aqiColor": "FFFFFF",
          "aqiSize": "16",
          "weatherIconSize": "24",
          "alertIconSize": "18",
          "padding": "10px 10px 10px 10px",
          "shadow": "0",
          "language": "auto",
          "fixed": "true",
          "vertical": "top",
          "horizontal": "left",
          "right": "10",
          "bottom": "10",
          "key": ""
        }
      }
      window.setTimeout(() => {
        let script = document.createElement('script')
        script.type = 'text/javascript'
        script.src =
                'https://widget.qweather.net/simple/static/js/he-simple-common.js?v=2.0'
        document.getElementsByTagName('head')[0].appendChild(script)
      },0)


    }
  }


</script>