<template>
    <div class="wrapper">
        <el-button type="text" size="medium" style="width: 30px;margin-left: 10px;" autocomplete="off" @click="$router.push('/front/home')">返回前台</el-button>
        <div style="margin: 50px auto; background-color: #fff; width: 350px; height: 330px; padding: 20px; border-radius: 10px">
            <div style="margin: 5px 0; text-align: center; font-size: 24px"><b>重置密码</b></div>
            <el-form :model="user" :rules="rules" ref="userForm">
                <el-form-item prop="username">
                    <el-input placeholder="请输入账号" size="medium" style="margin: 10px 0" prefix-icon="el-icon-user" v-model="user.username"></el-input>
                </el-form-item>
                <el-form-item >
                    <el-select v-model="user.question" placeholder="请选择密保问题" size="medium" style="width: 100%">
                        <el-option label="您的小学名称？" value="您的小学名称？"></el-option>
                        <el-option label="您印象最深的老师？" value="您印象最深的老师？"></el-option>
                        <el-option label="您父亲或母亲的名字？" value="您父亲或母亲的名字？"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="answer">
                    <el-input placeholder="输入密保，将密码重置为123456" size="medium" style="margin: 10px 0" prefix-icon="el-icon-question"  v-model="user.answer"></el-input>
                </el-form-item>

                <el-form-item style="margin: 5px 0; text-align: right">
                    <el-button type="warning" size="medium"  style="width: 45%;margin-right: 20px" autocomplete="off" @click="$router.push('/login')">返回登录</el-button>
                    <el-button type="primary" size="medium"  style="width: 45%;margin-left: 10px" autocomplete="off" @click="reset">重 置</el-button>

<!--                    <el-form-item type="primary" size="medium"  style="width: 45%;margin-left: 10px">-->
<!--                        <el-popconfirm-->
<!--                                class="ml-5"-->
<!--                                confirm-button-text='确定'-->
<!--                                cancel-button-text='我再想想'-->
<!--                                icon="el-icon-info"-->
<!--                                icon-color="red"-->
<!--                                title="您确定将密码重置为123456吗？"-->
<!--                                @confirm="reset"-->
<!--                        >-->
<!--                            <el-button  autocomplete="off">重 置</el-button>-->
<!--                        </el-popconfirm>-->
<!--                    </el-form-item>-->

                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Reset",
        data() {
            return {
                user: {},
                // user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},

                rules: {
                    username: [
                        { required: true, message: '请输入用户名', trigger: 'blur' },
                        { min: 3, max: 10, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                    ],
                    answer: [
                        { required: true, message: '输入密保答案，重置密码为123456', trigger: 'blur' },
                        { min: 1, max: 20, message: '长度在 1 到 20 个字符', trigger: 'blur' }
                    ],

                }
            }
        },
        methods: {
            reset() {
                this.$refs['userForm'].validate((valid) => {
                    if (valid) {  // 表单校验合法
                        // if (this.user.password !== this.user.confirmPassword) {
                        //     this.$message.error("两次输入的密码不一致")
                        //     return false
                        // }
                        this.request.get("/user/reset", {
                            params: {
                                username: this.user.username,
                                question: this.user.question,
                                answer: this.user.answer,

                            }
                        }).then(res => {
                            if(res.code === '200') {
                                this.$message.success("重置成功")
                                this.$router.push("/login")
                            } else {
                                this.$message.error("信息填写错误")
                                // this.$message.error(res.msg)
                            }
                        })
                    }
                });
            }
        }
    }
</script>

<style>
    .wrapper {
        height: 100vh;
        background-image: linear-gradient(to bottom right, #ffa165, #5673ff);
        overflow: hidden;
    }
    /*.wrapper {*/
    /*    height: 100vh;*/
    /*    background-image: linear-gradient(to bottom right, #FC466B , #3F5EFB);*/
    /*    overflow: hidden;*/
    /*}*/
</style>
