<template>
<!--    <el-card style="width: 900px;margin: 5px auto;">-->
    <el-tabs type="border-card" style="width: 800px;margin: 5px auto; ">
        <el-tab-pane label="个人信息">
            <el-form label-width="70px" size="small">
                <el-upload
                        class="avatar-uploader"
                        action="http://localhost:9090/fileavatar/upload"
                        :show-file-list="false"
                        :on-success="handleAvatarSuccess"
                >
                    <img v-if="form.avatarUrl" :src="form.avatarUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>

                <el-form-item label="用户名">
                    <el-input v-model="form.username" disabled autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="昵称">
                    <el-input v-model="form.nickname" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="邮箱">
                    <el-input v-model="form.email" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="密保问题">
                    <el-select v-model="form.question" placeholder="请选择问题类型" style="width: 100%">
                        <el-option label="您的小学名称？" value="您的小学名称？"></el-option>
                        <el-option label="您印象最深的人？" value="您印象最深的人？"></el-option>
                        <el-option label="您父亲或母亲的名字？" value="您父亲或母亲的名字？"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="答案">
                    <el-input type="textarea" v-model="form.answer" autocomplete="off"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-popconfirm
                            class="ml-5"
                            confirm-button-text='确定'
                            cancel-button-text='我再想想'
                            icon="el-icon-info"
                            icon-color="red"
                            title="您确定保存这些信息吗？"
                            @confirm="save"
                    >
                        <el-button type="primary" style="width: 100%; margin-left: -6px" slot="reference">确 定 </el-button>
                    </el-popconfirm>
<!--                    <el-button type="text" style="margin-left: 0px;" autocomplete="off" @click="$router.push('/password')">修改密码</el-button>-->
                </el-form-item>
            </el-form>
        </el-tab-pane>
        <el-tab-pane label="修改密码">
            <el-form label-width="100px" size="small" :model="passform" :rules="rules" ref="pass">

                <el-form-item label="原密码" prop="password">
                    <el-input v-model="passform.password" autocomplete="off" show-password></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newPassword">
                    <el-input v-model="passform.newPassword" autocomplete="off" show-password></el-input>
                </el-form-item>
                <el-form-item label="确认新密码" prop="confirmPassword">
                    <el-input v-model="passform.confirmPassword" autocomplete="off" show-password></el-input>
                </el-form-item>
                <el-form-item>
                    <el-popconfirm
                            class="ml-5"
                            confirm-button-text='确定'
                            cancel-button-text='我再想想'
                            icon="el-icon-info"
                            icon-color="red"
                            title="您确定修改密码？"
                            @confirm="passwordSave"
                    >
                        <el-button type="primary" style="width: 100%; margin-left: -6px" slot="reference">确 定 </el-button>
                    </el-popconfirm>
                    <!--                    <el-button type="text" style="margin-left: 0px;" autocomplete="off" @click="$router.push('/password')">修改密码</el-button>-->
                </el-form-item>

            </el-form>
        </el-tab-pane>
        <el-tab-pane label="在校登记信息">
            <el-form label-width="100px" size="small">
                <!--            v-if="user.role === 'ROLE_STUDENT'"-->
                <!--            v-if="user.role === 'ROLE_TEACHER'"-->
                <!--            v-if="user.role === 'ROLE_ADMIN'"-->
                <el-form-item v-if="user.role === 'ROLE_STUDENT'" label="学号" >
                    <el-input v-model="edu.id" disabled autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item v-if="user.role === 'ROLE_TEACHER'" label="教职工号" >
                    <el-input v-model="edu.id" disabled autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item v-if="user.role === 'ROLE_ADMIN'" label="管理员ID" >
                    <el-input v-model="edu.id" disabled autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="姓名">
                    <el-input v-model="edu.name" autocomplete="off"></el-input>
                </el-form-item>

<!--                <el-form-item label="性别" v-if="user.role !== 'ROLE_ADMIN'">-->
<!--                    <el-input v-model="edu.sex" autocomplete="off"></el-input>-->
<!--                </el-form-item>-->

                <el-form-item label="性别" v-if="user.role !== 'ROLE_ADMIN'">
                    <el-select v-model="edu.sex" placeholder="请选择" style="width: 100%">
                        <el-option label="男" value="男"></el-option>
                        <el-option label="女" value="女"></el-option>
                    </el-select>
                </el-form-item>


                <el-form-item label="出生年月" v-if="user.role !== 'ROLE_ADMIN'">
                    <el-date-picker
                            v-model="edu.birth"
                            type="date"
                            placeholder="选择或输入日期"
                            style="width: 100%">
                    </el-date-picker>
                    <!--                <el-input v-model="edu.birth" autocomplete="off"></el-input>-->
                </el-form-item>

                <el-form-item label="班级" v-if="user.role === 'ROLE_STUDENT'">
                    <el-input v-model="edu.classname" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="所在院系" v-if="user.role === 'ROLE_TEACHER'">
                    <el-input v-model="edu.department" autocomplete="off"></el-input>
                </el-form-item>

                <el-form-item label="手机号">
                    <el-input v-model="edu.phone" autocomplete="off"></el-input>
                </el-form-item>

                <el-form-item label="职称" v-if="user.role === 'ROLE_TEACHER'">
                    <el-input v-model="edu.grade" autocomplete="off"></el-input>
                </el-form-item>

                <el-form-item label="家庭地址" v-if="user.role !== 'ROLE_ADMIN'">
                    <el-input v-model="edu.address" type="textarea" autocomplete="off"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" style="width: 100%" v-if="user.role === 'ROLE_STUDENT'" @click="stusave">确 定</el-button>
                    <el-button type="primary" style="width: 100%" v-if="user.role === 'ROLE_TEACHER'" @click="teasave">确 定</el-button>
                    <el-button type="primary" style="width: 100%" v-if="user.role === 'ROLE_ADMIN'" @click="adminsave">确 定</el-button>
                </el-form-item>
            </el-form>
        </el-tab-pane>
    </el-tabs>


<!--    </el-card>-->
</template>

<script>
    export default {
        name: "Person",
        data() {
            return {
                form: {},
                passform: {},
                edu: {},
                user: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : {},

                rules: {
                    password: [
                        { required: true, message: '请输入原密码', trigger: 'blur' },
                        { min: 3, message: '长度不少于3位', trigger: 'blur' }
                    ],
                    newPassword: [
                        { required: true, message: '请输入新密码', trigger: 'blur' },
                        { min: 3, message: '长度不少于3位', trigger: 'blur' }
                    ],
                    confirmPassword: [
                        { required: true, message: '请输入密码', trigger: 'blur' },
                        { min: 3, message: '长度不少于3位', trigger: 'blur' }
                    ],
                },

            }
        },
        created() {
            this.getUser().then(res => {
                // console.log(res)
                this.form = res
            })
            this.passform.username = this.user.username
            this.getEdu().then(res => {
                // console.log(res)
                this.edu = res
                // console.log(edu)
            })
        },
        methods: {
            async getUser() {
                return (await this.request.get("/user/username/" + this.user.username)).data
            },
            save() {
                this.request.post("/user", this.form).then(res => {
                    if (res.code === '200') {
                        this.$message.success("保存成功")
                        // window.parent.location.reload(true)//刷新页面
                        //触发父级更新user的方法
                        this.$emit("refreshUser")

                        // 更新浏览器存储的用户信息
                        this.getUser().then(res => {
                            res.token = JSON.parse(localStorage.getItem("user")).token
                            localStorage.setItem("user", JSON.stringify(res))
                        })


                    } else {
                        this.$message.error("保存失败")
                    }
                })
            },
            handleAvatarSuccess(res) {
                this.form.avatarUrl = res
            },
            passwordSave() {
                this.$refs.pass.validate((valid) => {
                    if (valid) {
                        if (this.passform.newPassword !== this.passform.confirmPassword) {
                            this.$message.error("2次输入的新密码不相同")
                            return false
                        }
                        this.request.post("/user/password", this.passform).then(res => {
                            if (res.code === '200') {
                                this.$message.success("修改成功")
                                this.$store.commit("logout")
                            } else {
                                this.$message.error(res.msg)
                            }
                        })
                    }
                })
            },

            async getEdu() {
                if (this.user.role === 'ROLE_STUDENT'){
                    return (await this.request.get("/students/findone/" , {
                        params: {id: this.user.id}
                    } )).data
                } if (this.user.role === 'ROLE_TEACHER'){
                    return (await this.request.get("/teachers/findone/" , {
                        params: {id: this.user.id}
                    } )).data
                } else {
                    return (await this.request.get("/admin/findone/" , {
                        params: {id: this.user.id}
                    } )).data
                }
            },
            stusave() {
                this.request.post("/students/update/", this.edu).then(res => {
                    if (res.code === '200') {
                        this.$message.success("保存成功")
                    } else {
                        this.$message.error("保存失败")
                    }
                })
            },
            teasave() {
                this.request.post("/teachers/update/", this.edu).then(res => {
                    if (res.code === '200') {
                        this.$message.success("保存成功")
                    } else {
                        this.$message.error("保存失败")
                    }
                })
            },
            adminsave() {
                this.request.post("/admin/update/", this.edu).then(res => {
                    if (res.code === '200') {
                        this.$message.success("保存成功")
                    } else {
                        this.$message.error("保存失败")
                    }
                })
            },
        }
    }
</script>

<style>
    .avatar-uploader {
        text-align: center;
        padding-bottom: 10px;
    }
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 138px;
        height: 138px;
        line-height: 138px;
        text-align: center;
    }
    .avatar {
        width: 138px;
        height: 138px;
        display: block;
    }
</style>
