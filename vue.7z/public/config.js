export const serverIp = 'localhost'
// export const serverIp = '192.168.137.19'
