import pymysql

# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()
cur1 = db.cursor()
cur2 = db.cursor()
cur3 = db.cursor()
cur4 = db.cursor()
cur5 = db.cursor()
cur6 = db.cursor()
cur7 = db.cursor()

tru_sql = 'TRUNCATE TABLE list_coustatistics'
cur.execute(tru_sql)

select_sql = 'select DISTINCT number,coursename,attributes from list_course'
cur1.execute(select_sql)
rowadd = cur1.fetchall()


listcourse = []
def a_to(rows):
    a1, a2, a3 = zip(*rows)

    for i in a1:
        in_sql = 'INSERT INTO list_coustatistics (number) VALUES (%(aa)s)'
        cur1.execute(in_sql, {"aa": i})
        listcourse.append(i)

    j = 1
    for i in a2:
        up_sql = 'update list_coustatistics set coursename=%(aa)s  where id=%(j)s'
        # print(j)
        cur2.execute(up_sql, {"aa": i, "j": j})
        j = j + 1


    j = 1
    for i in a3:
        up_sql = 'update list_coustatistics set attributes=%(aa)s  where id=%(j)s'
        # print(j)
        cur3.execute(up_sql, {"aa": i, "j": j})
        j = j + 1

a_to(rowadd)

# db.commit()

j = 1
tempstr = ""
for i in listcourse:

    print(i)
    sel2_sql = 'select DISTINCT 实验项目数 from list_project where 课程代码 like %(i)s'
    cur4.execute(sel2_sql, {"i": i})
    rowadd2 = cur4.fetchall()
    # print(rowadd2)

    sel3_sql = 'select DISTINCT 面向专业 from list_project where 课程代码 like %(i)s'
    cur5.execute(sel3_sql, {"i": i})
    rowadd3 = cur5.fetchall()

    sel4_sql = 'select DISTINCT 面向专业数 from list_project where 课程代码 like %(i)s'
    cur6.execute(sel4_sql, {"i": i})
    rowadd4 = cur6.fetchall()
    # print(rowadd3)

    for (z), in rowadd2:
        # print(j)

            # print(int(j))
            up_sql = 'update list_coustatistics set projectnum=%(aa)s  where id=%(j)s'
            print(j)
            cur2.execute(up_sql, {"aa": z, "j": j})


    for (z), in rowadd3:
        # print(j)

            print(int(j))
            up_sql = 'update list_coustatistics set specialty=%(aa)s  where id=%(j)s'
            print(z)
            cur2.execute(up_sql, {"aa": z, "j": j})


    for (z), in rowadd4:
        # print(j)

            print(int(j))
            up_sql = 'update list_coustatistics set specialtynum=%(aa)s  where id=%(j)s'
            print(z)
            cur2.execute(up_sql, {"aa": int(z), "j": j})


    j = j + 1




# 提交SQL
db.commit()
# 4. 关闭游标
cur1.close()
cur2.close()
cur3.close()
cur4.close()
cur5.close()
cur6.close()
cur7.close()
# 5. 关闭连接
db.close()