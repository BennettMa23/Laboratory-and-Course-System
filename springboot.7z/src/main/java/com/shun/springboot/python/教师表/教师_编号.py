import pymysql
import os
import re

# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()
cur2 = db.cursor()

path = r'E:\Javaweb\files\文件另存为\教师课程'
# # 首先打开文件
# files = os.listdir(path)
# for i in files:
#     path1 = path + '\\' + i
#     # print(path1)
#     # print(files)
#     print(os.path.splitext(path1)[0])
list1 = os.listdir(path)
# print(os.listdir(path))

list2 = []
for i in list1:
    # print(os.path.splitext(i)[0])
    list2.append(os.path.splitext(i)[0])
    # print(list2)

inside = []
outside = []
j = 0
for i in list2:
    str1 = re.findall(r'[(](.*?)[)]', os.path.splitext(list2[j])[0])
    inside.append(str1)
    str2 = re.findall(r'(.*?)[(]', os.path.splitext(list2[j])[0])
    outside.append(str2)
    j = j + 1
print(inside)
print(outside)

# path1 = "test_user_info.py"
# print("suffix: {}".format(suffix))
# suffix = path1.split(".")[1]
try:
    create_sql = "CREATE TABLE tea_id_temp (teacher varchar(10),teaid bigint(20))"

    # 执行创建表
    cur.execute(create_sql)
    # # 提交SQL
    db.commit()
# try后面的执行失败，给出提示
except Exception as e:
    print("创建数据表失败:", e)
# try后面执行成功，给出提示
else:
    print("创建数据表成功")


for i in range(len(list2)):
    # print(i)
    in_sql = "INSERT into  tea_id_temp VALUES (%(nametemp)s,%(nums)s)"
    cur.execute(in_sql, { "nametemp": outside[i] , "nums": inside[i]})  # 整合一行

db.commit()
# 4. 关闭游标
cur.close()
# 5. 关闭连接
db.close()