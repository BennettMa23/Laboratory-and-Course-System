from sqlalchemy import create_engine
import pandas as pd
import os
import pymysql


# '''
# 课程清单数据库
# '''
# # 定义路径
# pathfiles = r'C:\Users\Shun\Desktop\老师另存为\课程清单\课程清单.xlsx'
#
# temp = pd.read_excel(pathfiles,skiprows=2,nrows=236, usecols=[3])
# # data = dropna(axis=0)
# temp.dropna(how='all', inplace=True)# 删除有空值的行
# print(temp)


path = r'E:\Javaweb\files\文件另存为\信息统计表'
# 首先打开文件
files = os.listdir(path)
for i in files:
    path1 = path + '\\' + i
    # skiprows = range(a, b)
    data = pd.read_excel(path1,sheet_name='实验课程实验项目统计表',header=2)
    # data = dropna(axis=0)
    data.dropna(how='all', inplace=True)  # 删除有空值的行
    # TRUNCATE    TABLE   class_course_temp

    # data.drop([0], inplace=True)
    # data.drop("备注", axis=1, inplace=True)  # 删除列
    data.drop("序号", axis=1, inplace=True)  # 删除列

    data['实验课程'] = data['实验课程'].fillna(method='ffill')
    data['课程代码'] = data['课程代码'].fillna(method='ffill')
    data['课程类别'] = data['课程类别'].fillna(method='ffill')
    data['实验项目数'] = data['实验项目数'].fillna(method='ffill')
    data['面向专业'] = data['面向专业'].fillna(method='ffill')
    data['面向专业数'] = data['面向专业数'].fillna(method='ffill')
    data['类别（本/专）'] = data['类别（本/专）'].fillna(method='ffill')

    # data['是否独立开课'] = data['是否独立开课'].fillna(data['是否独立开课'][1])
    # data['总学时'] = data['总学时'].fillna(data['总学时'][1])
    # data.copy()


    data.rename(columns={'项目类型\n（验证性/演示性/综合性/设计性）':'项目类型'},inplace=True)#更改命名
    data.rename(columns={'类别（本/专）':'类别'},inplace=True)#更改命名

    # for i in range(5, 10):
    #     data = data.append(pd.DataFrame({'教师号': [i]}), ignore_index=True)

    # for aa in range(data.shape[0]):
    #     data.insert(len(data.columns), '教师号',aa)#新建列

    # data.insert(len(data.columns), '教师号',999999990)#新建列
    # data.insert(len(data.columns), 'id', i[:7])


    # for i in data.iloc[:,0]:#取第一列全部值
    #     # print(i)
    #     str = ""
    #     sql = "SELECT DISTINCT 教师号 from list_class where 教师名 = %(teaname)s"
    #     cur.execute(sql, {"teaname": i})  # 整合一行
    #     rows = cur.fetchall()
    #
    #     for (j), in rows:
    #         tem = {"教师号": j}
    #         print(j)
    #
    #     print("##")



    # pd.read_excel()
    print(type(data))
    print(data.columns)
    engine = create_engine('mysql+mysqlconnector://root:123456@localhost:3306/webtest')
    # 上面这句，mysql是数据库类型，mysqlconnector是数据库驱动，root是用户名，123456
    # 是密码，localhost是地址，3306
    # 是端口，test是数据库名称
    print(data)
    # print(data.dtypes)

    data.to_sql(name='list_project', con=engine, if_exists="append", index=False)  # chunksize=100一次存100条
    print('导入' + i + '成功')


