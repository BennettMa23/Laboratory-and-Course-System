import pymysql
import re
# import MySQLdb


# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()


add_sql = "ALTER TABLE class_course_temp ADD id INT NOT NULL PRIMARY KEY AUTO_INCREMENT FIRST;"
cur.execute(add_sql)


select_sql = "SELECT Unname FROM class_course_temp ;"
cur.execute(select_sql)
rows = cur.fetchall()
print(rows)

num = 1
strtemp = ''
idnum = 1
for (row,) in rows:
    strtemp += row
    if(num % 4 == 0):
        in_sql = "update class_course_temp set Unname=%(na)s  where id=%(iid)s"
        cur.execute(in_sql,{"na":strtemp,"iid":idnum})#节次整合一行
        print(strtemp)

        idnum += 4
        strtemp = ''
        num = 0
    num += 1


print("完成")
# 提交SQL
db.commit()
# 4. 关闭游标
cur.close()
# 5. 关闭连接
db.close()