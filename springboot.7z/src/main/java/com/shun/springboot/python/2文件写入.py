# 先要安装几个库 sqlalchemy, pandas,mysql-connector
from sqlalchemy import create_engine
import pandas as pd
import os
import datetime
import numpy as np


starttime = datetime.datetime.now()
#每个班22条记录
# 定义路径
path = r'E:\Javaweb\files\room'
# temppath=r'E:\Javaweb\files\temp'
# 首先打开文件
files = os.listdir(path)
for i in files:
    path1 = path + '\\' + i
    data = pd.read_excel(path1,skiprows=1,nrows=22)
    # data = dropna(axis=0)
    data.dropna(how='all', inplace=True)# 删除有空值的行
    # TRUNCATE    TABLE   class_course_temp
    data.insert(len(data.columns), '教室',i[3:11])#新建列
    # data.insert(len(data.columns), 'id', i[:7])

    data.rename(columns={'Unnamed: 1':'Unname'},inplace=True)#更改未命名列
    data.rename(columns={'节  次':'节次'},inplace=True)#更改未命名列


    # pd.read_excel()
    print(type(data))
    print(data.columns)
    engine = create_engine('mysql+mysqlconnector://root:123456@localhost:3306/webtest')
    # 上面这句，mysql是数据库类型，mysqlconnector是数据库驱动，root是用户名，123456
    # 是密码，localhost是地址，3306
    # 是端口，test是数据库名称
    # print(data)
    # print(data.dtypes)

    data.to_sql(name='class_course_temp', con=engine, if_exists="append", index=False )  # chunksize=100一次存100条
    print('导入' + i + '成功')

    '''
    导入到mysql，这里有几个关键点，name是Table的名称，if_exists是指Table如果存在的几
    个处理办法，默认是报错，replace是先删后写入，append是添加，chunksize很关键，如
    果数据量较大，可以分批写入，chunksize后的数字就是每次写入的行数，可以加快运行速
    度，而且如果Table不存在，语句能自动创建，还能根据源数据自动调整Table字段的属
    性，效果很好
    '''

endtime = datetime.datetime.now()
x = endtime - starttime
print("运行时间：" + str(x.seconds),end='s')




