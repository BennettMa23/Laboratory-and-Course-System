import pymysql
import re
# import MySQLdb


# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()


select_sql = '''SELECT Unname FROM class_course_temp ;'''
cur.execute(select_sql)
rows = cur.fetchall()
# print(rows)

num = 1
strtemp = ''
idnum = 1
for (row,) in rows:#单元格主要内容转存
    strtemp += row
    if(num % 4 == 0):
        in_sql = "update class_course_temp set Unname=%(na)s  where id=%(iid)s"
        cur.execute(in_sql,{"na":strtemp,"iid":idnum})#节次整合一行
        # print(strtemp)

        idnum += 4
        strtemp = ''
        num = 0
    num += 1


select_sql = 'SELECT 星期一,星期二,星期三,星期四,星期五,星期六,星期日,Unname,教室 FROM class_course_temp ;'
cur.execute(select_sql)
rows = cur.fetchall()

# print(rows)
a1,a2,a3,a4,a5,a6,a7,a8,a9 = zip(*rows)
print(rows)


def a_to(aa):
    listtemp = []
    count = 0
    for i in range(len(aa)):
        if (i%4==0) or i==0 :
            if aa[i] == None:
                listtemp.append(aa[i])
                listtemp.append(aa[i])
                count += 2
                continue
            else:
                stra = aa[i]
                new1_str = ""
                # print(stra)
                for j in range(0, len(stra)):
                    if stra[j] == "(":
                        break
                    new1_str = new1_str + stra[j]
                listtemp.append(new1_str)
                listtemp.append(re.findall(r'[(](.*?)[)]', stra))

                count += 2
                if count == 5:
                    print(listtemp)
                    listtemp = []
                    count = 0
                continue

        count += 1
        listtemp.append(aa[i])
        if count == 5:
            if (listtemp[3] != None):
                strtr = ""
                strtr = listtemp[3]
                strtrtemp = ""
                for trtr in  range(len(strtr)):
                    strtrtemp = strtrtemp + strtr[trtr]
                    if (strtr[trtr] == " "):
                        break
                listtemp[3] =  strtrtemp
                print(listtemp[3])
                # print(listtemp)

                strtr4 = ""
                strtr4 = listtemp[4]
                strtrtemp = ""
                for trtr in range(len(strtr4)):
                    if (strtr4[trtr] == ";"):
                        strtrtemp = strtrtemp + ' '
                    else:
                        strtrtemp = strtrtemp + strtr4[trtr]
                listtemp[4] = strtrtemp

            insert_sql = 'INSERT INTO outword (course,course_number,teachers,weeks,classname) VALUES (%(aa)s,%(bb)s,%(cc)s,%(dd)s,%(ee)s);'
            cur.execute(insert_sql,{"aa":listtemp[0],"bb":listtemp[1],"cc":listtemp[2],"dd":listtemp[3],"ee":listtemp[4]})
            listtemp = []
            count = 0
# print(a5)
a_to(a1)
a_to(a2)
# go_sql = "SET @@global.sql_mode='';"
# cur.execute(go_sql)
# SET @@global.sql_mode='';
a_to(a3)
a_to(a4)
a_to(a5)

a_to(a6)
a_to(a7)

# print(a8)
# print(a9)

count_sql = "SELECT count(*) FROM outword"
cur.execute(count_sql)
temp = cur.fetchall()
for (inum,) in temp: print(inum)
print(type(inum))

temp = 0
iid = 1
# temp_sql = 'update outword set sections=""'
# cur.execute(temp_sql)
for i in range(inum):#存节次

    up_sql = 'update outword set sections=%(sname)s where id=%(cid)s'
    cur.execute(up_sql,{"sname": a8[temp][0:4],"cid":iid})
    if temp == 16:
        temp = -4
    iid += 1
    temp += 4

strtemp = []
strlast = []
for i in range(len(a9)):
    if i % 20 == 0 or i == 0:
        strtemp.append(a9[i])
    # print(i)
print(strtemp)
# for j in strtemp:
#     print(j)

# 提交SQL
db.commit()

for j in strtemp:#班级名去 (
    str1 = ''
    for k in j:
        # print(k)
        if k != '(':
            str1 += k
        else:
            continue
    strlast.append(str1)
print(strlast)

# for i in strlast:
#     print(i)


iid = 1
temp = 0
coutemp = 1
for i in range(inum):#存班级

    if coutemp <= 5:
        up_sql = 'update outword set classroom=%(cname)s where id=%(cid)s'
        cur.execute(up_sql,{"cname": strlast[temp],"cid":iid})
        # print(iid)
    if coutemp > 5:
        # 一个文件==0
        # 两个文件==1
        # 三个 ==2
        if temp == 1:
            temp = -1
        temp += 1
        up_sql = 'update outword set classroom=%(cname)s where id=%(cid)s'
        cur.execute(up_sql, {"cname": strlast[temp], "cid": iid})
        coutemp = 1
    iid += 1
    coutemp += 1


today = ['星期一','星期二','星期三','星期四','星期五','星期六','星期日']
iid = 1
temp = 0
coutemp = 1
endnum = inum/7
print(endnum)
for i in range(inum):#存星期
    if coutemp <= endnum:
        up_sql = 'update outword set is_today=%(cname)s where id=%(cid)s'
        cur.execute(up_sql,{"cname": today[temp],"cid":iid})
        # print(iid)
    if coutemp > endnum:
        if temp == 6:
            temp = -1
        temp += 1
        up_sql = 'update outword set is_today=%(cname)s where id=%(cid)s'
        cur.execute(up_sql, {"cname": today[temp], "cid": iid})
        coutemp = 1
    iid += 1
    coutemp += 1


print("完成")
# 提交SQL
db.commit()
# 4. 关闭游标
cur.close()
# 5. 关闭连接
db.close()