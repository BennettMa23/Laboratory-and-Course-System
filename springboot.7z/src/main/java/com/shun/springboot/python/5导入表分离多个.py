import pymysql
import uuid


# 1. 连接数据库
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.

# 2. 创建游标对象，
cur1 = db.cursor()
cur2 = db.cursor()
cur3 = db.cursor()
cur4 = db.cursor()
cur5 = db.cursor()
cur6 = db.cursor()



select_sql = "SELECT DISTINCT teachers FROM in_excel WHERE teachers is not null"
cur1.execute(select_sql)
rows = cur1.fetchall()
print(rows)


for (row,) in rows:
    teaid = int(uuid.uuid4())
    teaid = int(teaid / (999999999999999 * 9999999999999))
    # print(idd)
    insert_sql = "INSERT INTO bzu_teachers (id , name) VALUES (%(teaid)s ,%(names)s);"
    cur2.execute(insert_sql, {"teaid":teaid , "names": row})
    # print(row)

se_sql = "SELECT * FROM bzu_teachers"
cur3.execute(se_sql)
rows3 = cur3.fetchall()
print(rows3)

# 查询有几条数据
print(cur3.rownumber)

'''
selclass_sql = "SELECT classname FROM bzu_cou WHERE classname is not null"
cur4.execute(selclass_sql)
rows = cur4.fetchall()
print(rows)

for (row,) in rows:
    stuid = int(uuid.uuid4())
    stuid2 = int(stuid / (9998999999999999 * 99999999779999))
    print(stuid2)

    insert_sql = "INSERT INTO bzu_students (id , classes) VALUES (%(stuid)s ,%(cla)s);"
    cur5.execute(insert_sql, {"stuid":stuid2, "cla": row})
    # print(row)
'''

selclass_sql = "SELECT DISTINCT course_number,course FROM in_excel WHERE course_number is not null "
cur4.execute(selclass_sql)
rows = cur4.fetchall()
print(rows)

# listcou = [3]
for row in rows:
    listtemp = []
    for ro in row:
        listtemp.append(ro)

    print(listtemp)
    insert_sql = "INSERT INTO bzucourses (course_number , course ) VALUES (%(num)s ,%(cou)s);"
    cur5.execute(insert_sql, {"num": listtemp[0], "cou": listtemp[1]})


# 提交SQL
db.commit()

# 4. 关闭游标
cur1.close()
cur2.close()
cur3.close()
cur4.close()
cur5.close()
# 5. 关闭连接
db.close()
