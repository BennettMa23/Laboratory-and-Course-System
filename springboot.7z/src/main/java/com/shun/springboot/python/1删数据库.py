import pymysql

# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur1 = db.cursor()
cur2 = db.cursor()


try:
    del1_sql = "DROP TABLE outword"
    cur1.execute(del1_sql)
# try后面的执行失败，给出提示
except Exception as e:
    print("失败:", e)
# try后面执行成功，给出提示
else:
    print("成功")


try:
    del2_sql = "DROP TABLE class_course_temp"
    cur2.execute(del2_sql)
# try后面的执行失败，给出提示
except Exception as e:
    print("失败:", e)
# try后面执行成功，给出提示
else:
    print("成功")


# 提交SQL
db.commit()
# 4. 关闭游标
cur1.close()
cur2.close()
# 5. 关闭连接
db.close()