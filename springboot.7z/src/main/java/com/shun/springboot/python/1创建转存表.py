from openpyxl import load_workbook
import pymysql


# 1. 连接数据库，
# db = pymysql.connect("localhost", "root", "123456", "school")
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()
cur2 = db.cursor()


# 1). ************************创建数据表**********************************
try:
    # DROP TABLE in_excel;
    create_sql = "CREATE TABLE outword (classname varchar(50),teachers varchar(10),course varchar(50),course_number varchar(20)," \
                 "is_today varchar(5),classroom varchar(20),weeks varchar(50),sections varchar(20)," \
                 "id int(11) NOT NULL AUTO_INCREMENT,PRIMARY KEY (id) USING BTREE)"
# 执行创建表
    cur.execute(create_sql)
# try后面的执行失败，给出提示
except Exception as e:
    print("创建数据表失败:", e)
# try后面执行成功，给出提示
else:
    print("创建数据表成功;")

# 2). ************************创建数据表**********************************
try:
    # DROP TABLE outword;
    cre2_sql = "CREATE TABLE class_course_temp (节次 VARCHAR ( 10 ) DEFAULT NULL,Unname VARCHAR ( 10 ) DEFAULT NULL,星期一 text," \
               "星期二 text,星期三 text,星期四 text,星期五 text,星期六 text,星期日 text,时间 text,教室 text ) "
    # 执行创建表
    cur2.execute(cre2_sql)
# try后面的执行失败，给出提示
except Exception as e:
    print("创建数据表失败:", e)
# try后面执行成功，给出提示
else:
    print("创建数据表成功;")


# 提交SQL
db.commit()
# 4. 关闭游标
cur.close()
cur2.close()
# 5. 关闭连接
db.close()