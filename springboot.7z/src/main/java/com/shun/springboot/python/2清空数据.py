import pymysql
import os

dir_path = "E:/Javaweb/files/room"

for root,dirs,files in os.walk(dir_path):
    for file in files:
        os.remove(root+"/"+file)



# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur3 = db.cursor()

try:
    del3_sql = "TRUNCATE TABLE fileroom"
    cur3.execute(del3_sql)
# try后面的执行失败，给出提示
except Exception as e:
    print("失败:", e)
# try后面执行成功，给出提示
else:
    print("成功")


# 提交SQL
db.commit()
# 4. 关闭游标
cur3.close()
# 5. 关闭连接
db.close()