import pymysql
from docxtpl import DocxTemplate

doc = DocxTemplate(r"C:\Users\Shun\Desktop\新建文件夹 (2)\实验总课程表_模板.docx") # 读取模板
# context = { 't11' : "World company" } # 需要传入的字典， 需要在word对应的位置输入 {{ company_name }}
# doc.render(context) # 渲染到模板中
# doc.save("generated_doc.docx") # 生成一个新的模板


# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="javaweb")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur_tea = db.cursor()


sections_list = ['第一大节','第二大节','第三大节','第四大节','第五大节']
today_list = ['星期一','星期二','星期三','星期四','星期五','星期六','星期日']

temp_class = input("请输入教室名(如：6教6#304):")

tea_list = []

for i in today_list:

    for j in sections_list:
        sql1 = 'SELECT teachers FROM in_excel WHERE classroom = %(temp_class)s and isToday = %(i)s and sections = %(j)s'
        cur_tea.execute(sql1, {"temp_class": temp_class, "i": i, "j": j})
        sql_temp = cur_tea.fetchall()

        print(i)
        print(j)

        for (ii,) in sql_temp:
            # stri = '#'
            # if ii == None:
            #     tea_list.append(stri)
            tea_list.append(ii)

            print(ii)
# sql1 = 'SELECT teachers FROM in_excel WHERE classroom = %(temp_class)s and isToday = "星期一" and sections = "第三大节"'

# cur_tea.execute(sql1,{"temp_class":temp_class,"i":i,"j":j})
# sql_temp = cur_tea.fetchall()
# for (ii,) in sql_temp:print(ii)

print(tea_list)



context = {
    't51' : 3


} # 需要传入的字典， 需要在word对应的位置输入


doc.render(context) # 渲染到模板中
doc.save("generated_doc.docx") # 生成一个新的word


# # 4. 关闭游标
# cur.close()
# # 5. 关闭连接
# db.close()