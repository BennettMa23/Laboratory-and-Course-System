from sqlalchemy import create_engine
import pandas as pd
import os
# import datetime

path = r'E:\Javaweb\files\implement'
# 首先打开文件
files = os.listdir(path)
for i in files:
    path1 = path + '\\' + i

    # skiprows = range(a, b)
    data = pd.read_excel(path1,header=3,skipfooter=2)
    # data = dropna(axis=0)
    data.dropna(how='all', inplace=True)  # 删除有空值的行
    # TRUNCATE    TABLE   class_course_temp

    data.drop([0], inplace=True)
    data.drop("实验教材或实验指导书（出版社）", axis=1, inplace=True)  # 删除列

    data['实验课程名称'] = data['实验课程名称'].fillna(data['实验课程名称'][1])
    data['是否独立开课'] = data['是否独立开课'].fillna(data['是否独立开课'][1])
    data['总学时'] = data['总学时'].fillna(data['总学时'][1])
    # data.copy()

    str = pd.read_excel(path1, skiprows=2,nrows=1,)
    data.insert(len(data.columns), 'professional',str)#新建列
    # data.insert(len(data.columns), 'id', i[:7])

    data.rename(columns={'实验项目名称': 'projectname'}, inplace=True)  # 主键
    data.rename(columns={'实验课程名称':'coursename'},inplace=True)#更改列名
    data.rename(columns={'是否独立开课':'whether'},inplace=True)#更改列名
    data.rename(columns={'总学时':'hours'},inplace=True)#更改列名

    data.rename(columns={'学时数':'numberhours'},inplace=True)#更改列名
    data.rename(columns={'实验类型':'Type'},inplace=True)#更改列名
    data.rename(columns={'开出时间':'time'},inplace=True)#更改列名
    data.rename(columns={'实验指导教师':'teachername'},inplace=True)#更改列名
    data.rename(columns={'开课实验室':'classroom'},inplace=True)#更改列名

    # pd.read_excel()
    print(type(data))
    print(data.columns)
    engine = create_engine('mysql+mysqlconnector://root:123456@localhost:3306/webtest')
    # 上面这句，mysql是数据库类型，mysqlconnector是数据库驱动，root是用户名，123456
    # 是密码，localhost是地址，3306
    # 是端口，test是数据库名称
    print(data)
    # print(data.dtypes)

    data.to_sql(name='list_implement', con=engine, if_exists="append", index=False)  # chunksize=100一次存100条
    print('导入' + i + '成功')


