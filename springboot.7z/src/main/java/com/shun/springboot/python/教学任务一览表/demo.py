import pymysql

# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()
cur1 = db.cursor()
cur2 = db.cursor()
cur3 = db.cursor()
cur4 = db.cursor()
cur5 = db.cursor()
cur6 = db.cursor()

tru_sql = 'TRUNCATE TABLE list_task'
cur.execute(tru_sql)


# sel1_sql = 'select classname from list_course'
# cur1.execute(sel1_sql)
# rows = cur1.fetchall()

select_sql = 'select classname,number,coursename,experimental,classname,selection from list_course'
cur1.execute(select_sql)
rowadd = cur1.fetchall()

# a1,a2,a3,a4,a5,a6 = zip(*rowadd)
# print(rowadd)
# print(a1)


def a_to(rows):
    a1, a2, a3, a4, a5, a6 = zip(*rows)
    # print(rows)
    list1 = []  # 专业名
    for i in a1:
        strtemp = str(i)
        str1 = ''
        str2 = ''
        num = 0
        print(i)
        if (i == None):
            str123 = ''
            list1.append(str123)
            in_sql = 'INSERT INTO list_task (profession) VALUES (%(aa)s)'
            cur2.execute(in_sql, {"aa": str123})
        else:
            # if type(strtemp) != 'str':
            #     v = str(strtemp)
            # leng = len(i)
            # print(leng)
            if (len(strtemp) > 9):
                for j in strtemp:
                    num = num + 1
                    if (j != ','):
                        if (num > 2):
                            str1 = str1 + j

                            # print(str2)


                    else:
                        if (num > 2):
                            # print(str1)
                            b = list(str1)
                            b.pop()
                            str2 = ''.join(b)
                            str1 = str2 + '、'
                            num = 0
                            # str2 = ''

                b = list(str1)
                b.pop()
                str2 = ''.join(b)
                # print(str2)
                list1.append(str2)

            else:
                for j in strtemp:
                    num = num + 1
                    if (num > 2):
                        str1 = str1 + j

                        b = list(str1)
                        b.pop()
                        str2 = ''.join(b)
                        # print(str2)
            # print(str2)
            list1.append(str2)

            in_sql = 'INSERT INTO list_task (profession) VALUES (%(aa)s)'
            cur2.execute(in_sql, {"aa": str2})
    # print(list1)

    # 提交SQL
    db.commit()

    j = 1
    for i in a2:
        up_sql = 'update list_task set number=%(a2)s  where id=%(j)s'
        # print(i)
        cur2.execute(up_sql, {"a2": i,"j": j})
        j = j+1

    j = 1
    for i in a3:
        up_sql = 'update list_task set coursename=%(a2)s  where id=%(j)s'
        # print(j)

        cur2.execute(up_sql, {"a2": i, "j": j})
        j = j + 1

    j = 1
    for i in a4:
        up_sql = 'update list_task set experimental=%(a2)s  where id=%(j)s'
        # print(i)
        cur2.execute(up_sql, {"a2": i, "j": j})
        j = j + 1

    j = 1
    for i in a5:
        up_sql = 'update list_task set classname=%(a2)s  where id=%(j)s'
        # print(j)
        cur2.execute(up_sql, {"a2": i, "j": j})
        j = j + 1

    j = 1
    for i in a6:
        up_sql = 'update list_task set man=%(a2)s  where id=%(j)s'
        # print(j)
        cur2.execute(up_sql, {"a2": i, "j": j})
        j = j + 1

a_to(rowadd)
db.commit()


# select_sql = 'select DISTINCT 实验项目数 from list_project where 课程代码 = "1114057H"'
# cur1.execute(select_sql)
# rowadd2 = cur1.fetchall()
#
# a1,a2,a3,a4,a5,a6 = zip(*rowadd2)
# print(rowadd2)
# print(a1)


# 提交SQL
db.commit()
# 4. 关闭游标
cur1.close()
cur2.close()
cur3.close()
cur4.close()
cur5.close()
cur6.close()
# 5. 关闭连接
db.close()