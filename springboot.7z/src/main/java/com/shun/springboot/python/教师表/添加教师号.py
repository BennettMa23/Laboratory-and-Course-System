import pymysql

# 1. 连接数据库，
db = pymysql.connect(host="localhost", user="root", password="123456", database="webtest")
# ****python, 必须有一个游标对象， 用来给数据库发送sql语句， 并执行的.
# 2. 创建游标对象，
cur = db.cursor()
cur2 = db.cursor()
cur3 = db.cursor()

sel_sql = "select DISTINCT 姓名 from list_tea;"
cur.execute(sel_sql)
rows = cur.fetchall()

cou = 0
teaid = []
for (i), in rows:
    sel2_sql = "SELECT DISTINCT teaid from tea_id_temp where teacher = %(nname)s"
    cur2.execute(sel2_sql, {"nname": i})  # 整合一行
    rows2 = cur2.fetchall()
    # print(i)
    for (j), in rows2:
        up_sql = "update list_tea set id=%(nums)s  where 姓名=%(nametemp)s"
        cur.execute(up_sql, {"nums": j, "nametemp": i})  # 整合一行
        print(j)
        cou = cou + 1

print(cou)

# rows = cur.fetchall()
# for (i), in rows:
#     up_sql = "update list_tea set id=%(nums)s  where 姓名=%(nametemp)s"
#     cur.execute(up_sql, {"nums": j, "nametemp": i})  # 整合一行
#     print(i)
#     print(j)



# 执行创建表
# cur.execute(create_sql)

# 提交SQL
db.commit()
# 4. 关闭游标
cur.close()
# 5. 关闭连接
db.close()