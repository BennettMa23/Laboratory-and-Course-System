# 先要安装几个库 sqlalchemy, pandas,mysql-connector
from sqlalchemy import create_engine
import pandas as pd
import os
# import datetime
# import numpy as np

'''
课程清单数据库
'''
# 定义路径
path = r'E:\Javaweb\files\文件另存为\课程清单'
# 首先打开文件
files = os.listdir(path)
for i in files:
    path1 = path + '\\' + i
    data = pd.read_excel(path1,skiprows=2,nrows=236)
    # data = dropna(axis=0)
    data.dropna(how='all', inplace=True)# 删除有空值的行
    # TRUNCATE    TABLE   class_course_temp

    data.drop("星期一",axis=1,inplace=True)#删除列
    data.drop("星期二",axis=1,inplace=True)#删除列
    data.drop("星期三",axis=1,inplace=True)#删除列
    data.drop("星期四",axis=1,inplace=True)#删除列
    data.drop("星期五",axis=1,inplace=True)#删除列
    data.drop("星期六",axis=1,inplace=True)#删除列
    data.drop("星期日",axis=1,inplace=True)#删除列
    data.drop("任务校区",axis=1,inplace=True)#删除列
    data.drop("备注",axis=1,inplace=True)#删除列

    # data.insert(len(data.columns), '班级',i[:6])#新建列
    # data.insert(len(data.columns), 'id', i[:7])

    data.rename(columns={'课程号':'number'},inplace=True)#更改列命名
    data.rename(columns={'课序':'sequence'},inplace=True)#更改列命名
    data.rename(columns={'课程名':'coursename'},inplace=True)#更改列命名
    data.rename(columns={'教师号':'teachernumber'},inplace=True)#更改列命名
    data.rename(columns={'教师名':'teachername'},inplace=True)#更改列命名
    data.rename(columns={'职称':'title'},inplace=True)#更改列命名
    data.rename(columns={'开课院系':'facultyanddepartments'},inplace=True)#更改列命名
    data.rename(columns={'授课语种':'language'},inplace=True)#更改列命名
    data.rename(columns={'课程属性':'attributes'},inplace=True)#更改列命名
    data.rename(columns={'"考试_x000D_\n类型"':'exsam'},inplace=True)#更改列命名
    data.rename(columns={'班级':'classname'},inplace=True)#更改列命名
    data.rename(columns={'课容量':'capacity'},inplace=True)#更改列命名
    data.rename(columns={'总学时':'hours'},inplace=True)#更改列命名
    data.rename(columns={'周学时':'weekhours'},inplace=True)#更改列命名
    data.rename(columns={'授课学时':'teachinghours'},inplace=True)#更改列命名
    data.rename(columns={'上机学时':'computertime'},inplace=True)#更改列命名
    data.rename(columns={'实验学时':'experimental'},inplace=True)#更改列命名
    data.rename(columns={'学分':'credit'},inplace=True)#更改列命名
    data.rename(columns={'上课地点':'classroom'},inplace=True)#更改列命名
    data.rename(columns={'上课周次':'weeks'},inplace=True)#更改列命名
    data.rename(columns={'"选课_x000D_\n人数"':'selection'},inplace=True)#更改列命名

    # data.rename(columns={'课序':'id'},inplace=True)#更改列命名


    # pd.read_excel()
    print(type(data))
    print(data.columns)
    engine = create_engine('mysql+mysqlconnector://root:123456@localhost:3306/webtest')
    # 上面这句，mysql是数据库类型，mysqlconnector是数据库驱动，root是用户名，123456
    # 是密码，localhost是地址，3306
    # 是端口，test是数据库名称
    # print(data)
    # print(data.dtypes)

    data.to_sql(name='list_course', con=engine, if_exists="append", index=False )  # chunksize=100一次存100条
    print('导入' + i + '成功')

    '''
    导入到mysql，这里有几个关键点，name是Table的名称，if_exists是指Table如果存在的几
    个处理办法，默认是报错，replace是先删后写入，append是添加，chunksize很关键，如
    果数据量较大，可以分批写入，chunksize后的数字就是每次写入的行数，可以加快运行速
    度，而且如果Table不存在，语句能自动创建，还能根据源数据自动调整Table字段的属
    性，效果很好
    '''

# '''
# 任务落实情况一览表
# '''
# path = r'C:\Users\Shun\Desktop\老师另存为\任务落实情况表'
# # 首先打开文件
# files = os.listdir(path)
# for i in files:
#     path1 = path + '\\' + i
#
#     # skiprows = range(a, b)
#     data = pd.read_excel(path1,header=3,skipfooter=2)
#     # data = dropna(axis=0)
#     data.dropna(how='all', inplace=True)  # 删除有空值的行
#     # TRUNCATE    TABLE   class_course_temp
#
#     data.drop([0], inplace=True)
#     data.drop("实验教材或实验指导书（出版社）", axis=1, inplace=True)  # 删除列
#
#     data['实验课程名称'] = data['实验课程名称'].fillna(data['实验课程名称'][1])
#     data['是否独立开课'] = data['是否独立开课'].fillna(data['是否独立开课'][1])
#     data['总学时'] = data['总学时'].fillna(data['总学时'][1])
#     # data.copy()
#     data.insert(len(data.columns), 'professional',df.iloc[[2],[0]])#新建列
#     # data.insert(len(data.columns), 'id', i[:7])
#
#     data.rename(columns={'实验项目名称': 'projectname'}, inplace=True)  # 主键
#     data.rename(columns={'实验课程名称':'coursename'},inplace=True)#更改列名
#     data.rename(columns={'是否独立开课':'whether'},inplace=True)#更改列名
#     data.rename(columns={'总学时':'hours'},inplace=True)#更改列名
#
#     data.rename(columns={'学时数':'numberhours'},inplace=True)#更改列名
#     data.rename(columns={'实验类型':'Type'},inplace=True)#更改列名
#     data.rename(columns={'开出时间':'time'},inplace=True)#更改列名
#     data.rename(columns={'实验指导教师':'teachername'},inplace=True)#更改列名
#     data.rename(columns={'开课实验室':'classroom'},inplace=True)#更改列名
#
#     # pd.read_excel()
#     print(type(data))
#     print(data.columns)
#     engine = create_engine('mysql+mysqlconnector://root:123456@localhost:3306/webtest')
#     # 上面这句，mysql是数据库类型，mysqlconnector是数据库驱动，root是用户名，123456
#     # 是密码，localhost是地址，3306
#     # 是端口，test是数据库名称
#     print(data)
#     # print(data.dtypes)
#
#     data.to_sql(name='list_implement', con=engine, if_exists="append", index=False)  # chunksize=100一次存100条
#     print('导入' + i + '成功')
#
#
