package com.shun.springboot.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.shun.springboot.utils.AndClass;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class out2 {
    public static void main(String[] args) {
        String classroom = "407";
        String username = "他妈的";
        String strurl = "src\\main\\resources\\poi\\实验总课程表模板.docx";


        RestTemplate restTemplate = new RestTemplate();
        Map<String,Object> mapand1 = new HashMap<>();
        Map<String,Object> mapand2 = new HashMap<>();
        Map<String,Object> mapadd = new HashMap<>();

        String[] weeklist = {"星期一","星期二","星期三","星期四","星期五"};
        String[] sectlist = {"第一大节","第二大节","第三大节","第四大节","第五大节"};

        for (int i = 0; i < weeklist.length; i++) {
            for (int j = 0; j < sectlist.length; j++) {

                Map<String, String> Mapfor = new HashMap<>();
                Mapfor.put("classroom", classroom);
                Mapfor.put("isToday", weeklist[i]);
                Mapfor.put("sections", sectlist[j]);
                String strfor = restTemplate.getForObject("http://localhost:9090/outword/" +
                        "out?classroom={classroom}&isToday={isToday}&sections={sections}", String.class, Mapfor);
                JSONObject obj1 = JSONObject.parseObject(strfor);
                JSONObject obj2 = (JSONObject) obj1.get("data");
                JSONArray arr3 = (JSONArray) obj2.get("records");

                System.out.println(arr3);
                System.out.println("++++" + arr3.size());
                System.out.println("++++" + arr3.get(0));

                if(arr3.size() == 1){
                    Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
                    map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
                    System.out.println(map1);
//                    System.out.println(map1.get(1));

                    Map<String,Object> maptemp = new HashMap<>();
                    if (map1.size() > 2){
//                        Map<String,Object> maptemp = new HashMap<>();
                        for (Object obj : map1.keySet()){
                            maptemp.put(obj+String.valueOf(i)+j,map1.get(obj));
                        }
                    } else {
//                        Map<String,Object> maptemp = new HashMap<>();
                        maptemp.put("classname"+i+j, " ");
                        maptemp.put("teachers"+i+j, " ");
                        maptemp.put("course"+i+j, " ");
                        maptemp.put("courseNumber"+i+j, " ");
                        maptemp.put("classroom"+i+j, " ");
                        maptemp.put("weeks"+i+j, " ");
                    }

                    mapand1.putAll(maptemp);
//                        mapand1.putAll(mapand1);
                    System.out.println("1>>>>>>>>>"+maptemp);
                    System.out.println("1>>>>>>>>>"+mapand1);
                }else if (arr3.size() == 2){
                    Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
//                    System.out.println("!!!!"+ map1);
                    Map map2 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(1)));
//                    System.out.println("!!!!"+ map2.get("classname"));
                    String strtemp = (String) map1.get("classname") +"\n"+ map2.get("classname");
                    map1.put("classname", strtemp);
                    map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");

                    Map<String,Object> maptemp = new HashMap<>();
                    for (Object obj : map1.keySet()){
                        maptemp.put(obj+String.valueOf(i)+j, map1.get(obj));
                    }

                    mapand1.putAll(maptemp);
//                        mapand1.putAll(mapand1);
//                    System.out.println("2>>>>>>>>>"+maptemp);
//                    System.out.println("2>>>>>>>>>"+mapand1);
                }else {
                    Map<String,Object> map1 = new HashMap<>();
                    map1.put("classname"+i+j, " ");
                    map1.put("teachers"+i+j, " ");
                    map1.put("course"+i+j, " ");
                    map1.put("courseNumber"+i+j, " ");
                    map1.put("classroom"+i+j, " ");
                    map1.put("weeks"+i+j, " ");

                    mapand1.putAll(map1);
//                    System.out.println("3>>>>>>>>>"+map1);
//                    System.out.println("3>>>>>>>>>"+mapand1);
                }

//                System.out.println("@@@@@@@@@@@@@@"+mapand1);
            }
        }
//        System.out.println(mapand1);


        //22222222222222222222222222222222222222222222222222222222
        String classroom2 = AndClass.classroom(classroom);
        System.out.println("############"+classroom2);
        for (int i = 0; i < weeklist.length; i++) {
            for (int j = 0; j < sectlist.length; j++) {
                Map<String, String> Mapfor = new HashMap<>();
                Mapfor.put("classroom", classroom2);
                Mapfor.put("isToday", weeklist[i]);
                Mapfor.put("sections", sectlist[j]);
                String strfor = restTemplate.getForObject("http://localhost:9090/outword/" +
                        "out?classroom={classroom}&isToday={isToday}&sections={sections}", String.class, Mapfor);
                JSONObject obj1 = JSONObject.parseObject(strfor);
                JSONObject obj2 = (JSONObject) obj1.get("data");
                JSONArray arr3 = (JSONArray) obj2.get("records");


                if(arr3.size() == 1){
                    Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
                    map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");

                    Map<String,Object> maptemp = new HashMap<>();


                    if (map1.size() > 2){
//                        Map<String,Object> maptemp = new HashMap<>();
                        for (Object obj : map1.keySet()){
                            maptemp.put(obj+"2"+i+j,map1.get(obj));
                        }
                    } else {
//                        Map<String,Object> maptemp = new HashMap<>();
                        maptemp.put("classname"+i+j, " ");
                        maptemp.put("teachers"+i+j, " ");
                        maptemp.put("course"+i+j, " ");
                        maptemp.put("courseNumber"+i+j, " ");
                        maptemp.put("classroom"+i+j, " ");
                        maptemp.put("weeks"+i+j, " ");
                    }

                    mapand2.putAll(maptemp);

//                        mapand2.putAll(mapand2);
//                    System.out.println("1>>>>>>>>>"+maptemp);
//                    System.out.println("1>>>>>>>>>"+mapand2);
                }else if (arr3.size() == 2){
                    Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
//                    System.out.println("!!!!"+ map1);
                    Map map2 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(1)));
//                    System.out.println("!!!!"+ map2.get("classname"));
                    String strtemp = (String) map1.get("classname") +"\n"+ map2.get("classname");
                    map1.put("classname", strtemp);
                    map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");

                    Map<String,Object> maptemp = new HashMap<>();
                    for (Object obj : map1.keySet()){
                        maptemp.put(obj+"2"+i+j, map1.get(obj));
                    }

                    mapand2.putAll(maptemp);
//                        mapand2.putAll(mapand2);
//                    System.out.println("2>>>>>>>>>"+maptemp);
//                    System.out.println("2>>>>>>>>>"+mapand2);
                }else {
                    Map<String,Object> map1 = new HashMap<>();
                    map1.put("classname"+"2"+i+j, " ");
                    map1.put("teachers"+"2"+i+j, " ");
                    map1.put("course"+"2"+i+j, " ");
                    map1.put("courseNumber"+"2"+i+j, " ");
                    map1.put("classroom"+"2"+i+j, " ");
                    map1.put("weeks"+"2"+i+j, " ");

                    mapand2.putAll(map1);
//                    System.out.println("3>>>>>>>>>"+map1);
//                    System.out.println("3>>>>>>>>>"+mapand2);
                }

//                System.out.println("@@@@@@@@@@@@@@"+mapand2);
            }
        }

        mapadd.putAll(mapand1);
        mapadd.putAll(mapand2);

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = new java.util.Date();//在时间前加上java.util就可以了
        String strdate = df.format(date);

        mapadd.put("isname", username);
        mapadd.put("Time", strdate);


        System.out.println("@@@@@@@@@@@@@@"+mapadd);


//            return mapadd;




    }
}
