package com.shun.springboot.test;

import cn.hutool.core.util.ArrayUtil;
import com.alibaba.fastjson.*;
import com.shun.springboot.entity.Outword;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.web.client.RestTemplate;

import java.sql.Array;
import java.util.HashMap;
import java.util.Map;


public class out {
    public static void main(String[] args) {
        RestTemplate restTemplate = new RestTemplate();
        String classroom = "407";
//        String classroom = "6教6%23210";
        String isToday = "星期一";
        String sections = "第二大节";


        Map<String, String> hashMap = new HashMap<>();
        hashMap.put("classroom", classroom);
        hashMap.put("isToday", isToday);
        hashMap.put("sections", sections);


        String str = restTemplate.getForObject("http://localhost:9090/outword/out?classroom={classroom}&isToday={isToday}&sections={sections}", String.class, hashMap);
        JSONObject obj1 = JSONObject.parseObject(str);

        JSONObject obj2 = (JSONObject) obj1.get("data");

        System.out.println(obj2.get("total"));

        JSONArray arr3 = (JSONArray) obj2.get("records");
//        System.out.println(arr3);
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n###########"+arr3);
        Map<String,Object> mapdata = new HashMap<>();

//        String[] weeklist = {"星期一","星期二","星期三","星期四","星期五"};
//        String[] sectlist = {"第一大节","第二大节","第三大节","第四大节","第五大节"};
//        for(String we : weeklist){
//            for(String se : sectlist){
//                System.out.println(we + se);
//            }
//        }

        for (int i = 1; i <= 2; i++) {
            if(arr3.size() == i && i == 1){
                Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
                map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");

                mapdata.putAll(map1);
                System.out.println(map1);
            }else if (arr3.size() > i && i == 1){
                Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
                System.out.println("!!!!"+ map1);
                Map map2 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(1)));
                System.out.println("!!!!"+ map2.get("classroom"));
                String strtemp = (String) map1.get("classroom") +"\n"+ map2.get("classroom");
                map1.put("classroom", strtemp);
                map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");

//                int num = 1;
//                for (Object obj : map1.keySet()){
//                    System.out.println(obj+String.valueOf(num) +"\t 值为：\t"+map1.get(obj));
//                }

                mapdata.putAll(map1);
                System.out.println(map1);
            }else {
                Map<String,Object> map1 = new HashMap<>();
                map1.put("classname"+i, "");
                map1.put("teachers"+i, "");
                map1.put("course"+i, "");
                map1.put("courseNumber"+i, "");
                map1.put("classroom"+i, "");
                map1.put("weeks"+i, "");

                mapdata.putAll(map1);
//                System.out.println(map1.get("classname1"));
            }
        }

        System.out.println(mapdata);

//        String str = restTemplate.getForObject("http://localhost:9090/outword/out?classroom="+classroom+"&isToday="+isToday+"&sections="+sections , String.class);
//        JSONObject obj1 = JSONObject.parseObject(str);
//
//
//        //获取json中data数据
////        System.out.println(object.get("data"));
////        System.out.println(object.get("data").getClass());
//        JSONObject obj2 = (JSONObject) obj1.get("data");
//
//        //System.out.println(obj2.get("total"));
//
//        JSONArray arr3 = (JSONArray) obj2.get("records");
//        System.out.println(arr3);
//
//        Map<String,Object> mapdata = new HashMap<>();
//
//        for (int i = 1; i <= 25; i++) {
//
//            if(arr3.size() == 0){
//                Map<String,Object> map1 = new HashMap<>();
//
//                map1.put("classname"+i, "");
//                map1.put("teachers"+i, "");
//                map1.put("course"+i, "");
//                map1.put("courseNumber"+i, "");
//                map1.put("classroom"+i, "");
//                map1.put("weeks"+i, "");
//
//                mapdata.putAll(map1);
////                System.out.println(map1.get("classname1"));
//
//            } else if(arr3.size() == 1){
//                Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
//                map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
//
//                mapdata.putAll(map1);
//                System.out.println(map1);
//            }else {
//                Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
//                System.out.println("!!!!"+ map1);
//                Map map2 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(1)));
//                System.out.println("!!!!"+ map2.get("classroom"));
//                String strtemp = (String) map1.get("classroom") +"\n"+ map2.get("classroom");
//                map1.put("classroom", strtemp);
//                map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
//
////                int num = 1;
////                for (Object obj : map1.keySet()){
////                    System.out.println(obj+String.valueOf(num) +"\t 值为：\t"+map1.get(obj));
////                }
//
//                mapdata.putAll(map1);
//                System.out.println(map1);
//            }
//        }
//
//        System.out.println(mapdata);
//
//
//
//
//
////        if(arr3.size() == 0){
////            Map<String,Object> map1 = new HashMap<>();
////
////            map1.put("classname", "");
////            map1.put("teachers", "");
////            map1.put("course", "");
////            map1.put("courseNumber", "");
////            map1.put("classroom", "");
////            map1.put("weeks", "");
////
////            int num = 1;
////            for (Object obj : map1.keySet()){
////                System.out.println(obj+String.valueOf(num) +"\t 值为：\t"+map1.get(obj));
////            }
////
////            System.out.println(map1.get("classname"));
////
////        } else if(arr3.size() == 1){
////            Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
////            map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
////
////            System.out.println(map1);
////        }else {
////            Map map1 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(0)));
////            System.out.println("!!!!"+ map1);
////            Map map2 = JSON.parseObject(String.valueOf((JSONObject) arr3.get(1)));
////            System.out.println("!!!!"+ map2.get("classroom"));
////            String strtemp = (String) map1.get("classroom") +"\n"+ map2.get("classroom");
////            map1.put("classroom", strtemp);
////            map1.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
////
////            int num = 1;
////            for (Object obj : map1.keySet()){
////                System.out.println(obj+String.valueOf(num) +"\t 值为：\t"+map1.get(obj));
////            }
////
////            System.out.println(map1);
////        }
//
////        System.out.println(obj2.get("classname"));
////        System.out.println(obj2.get("classname").getClass());
////        System.out.println(obj2.getClass());
//
//
////        int num = 1;
////        Map mapTypes = JSON.parseObject(String.valueOf((JSONObject) obj1.get("data")));
////        System.out.println(mapTypes);
////
////
////        mapTypes.keySet().removeIf(key -> key == "id" || key == "is_today" || key == "sections");
////
////        System.out.println("这个是用JSON类的parseObject来解析JSON字符串!!!");
////        for (Object obj : mapTypes.keySet()){
//////            if (obj == "id") continue;
//////            if (obj == "is_today") continue;
//////            if (obj == "sections") continue;
////
////            System.out.println(obj+String.valueOf(num) +"\t 值为：\t"+mapTypes.get(obj));
////        }
//



    }

}
