package com.shun.springboot.test;

import java.text.SimpleDateFormat;

public class str {
    public static void main(String[] args) {
        String str = "407";
        String str1 = str.substring(0, str.length() -1);
        System.out.println("->"+str1);

//        最后输出的结果为 hell 最后一个字符被截取了

        String str2 = str.substring(str.length()-1);
        int temp = Integer.parseInt(str2);
        if (temp % 2 != 0)
            temp ++;
        else
            temp --;


        System.out.println(temp);

        String strand = str1 + temp;
        System.out.println(strand);

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = new java.util.Date();//在时间前加上java.util就可以了
        String strdate = df.format(date);
        System.out.println(strdate);
    }
}
