package com.shun.springboot.controller;

import ch.qos.logback.core.util.FileUtil;
import cn.afterturn.easypoi.word.WordExportUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shun.springboot.utils.AndClass;
import org.apache.coyote.Response;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shun.springboot.common.Result;

import com.shun.springboot.service.IOutwordService;
import com.shun.springboot.entity.Outword;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-27
 */
@ResponseBody
@RestController
@RequestMapping("/outword")
public class OutwordController {
    
    @Resource
    private IOutwordService outwordService;

    @GetMapping("/toword")
    public Result outword(@RequestParam(defaultValue = "") String classroom,
                          @RequestParam(defaultValue = "") String username,
//                          @RequestParam(defaultValue = "C:\\Users\\Shun\\Desktop\\新建文件夹 (2)") String filePath,
                          @RequestParam(defaultValue = "src\\main\\resources\\poi\\实验总课程表模板.docx") String strurl,
                          HttpServletResponse response){

        Map<String,Object> mapadd = outwordService.downloadWord(classroom,username,strurl);

        try {
            XWPFDocument doc = WordExportUtil.exportWord07(strurl, mapadd);
            //下载文件
            outwordService.downloadFile(response, doc);
        } catch (Exception e) {
            e.printStackTrace();
        }

//        return Result.success(mapadd);
        return null;
    }


    @GetMapping("/out")
    public Result findTea(@RequestParam(defaultValue = "") String classroom,
                                 @RequestParam(defaultValue = "") String isToday,
                                 @RequestParam(defaultValue = "") String sections,
                                 @RequestParam(defaultValue = "") String course,
                                 @RequestParam(defaultValue = "") String courseNumber,
                                 @RequestParam(defaultValue = "") String classname,
                                 @RequestParam(defaultValue = "") String teachers,
                                 @RequestParam(defaultValue = "") String weeks ) {
        QueryWrapper<Outword> queryWrapper = new QueryWrapper<>();
        if (!"".equals(classroom)) {
            queryWrapper.like("classroom", classroom);
        }
        if (!"".equals(isToday)) {
            queryWrapper.like("is_today", isToday);
        }
        if (!"".equals(sections)) {
            queryWrapper.like("sections", sections);
        }
        if (!"".equals(course)) {
            queryWrapper.like("course", course);
        }
        if (!"".equals(courseNumber)) {
            queryWrapper.like("course_number", courseNumber);
        }
        if (!"".equals(classname)) {
            queryWrapper.like("classname", classname);
        }
        if (!"".equals(teachers)) {
            queryWrapper.like("teachers", teachers);
        }
        if (!"".equals(weeks)) {
            queryWrapper.like("weeks", weeks);
        }

//        outwordService.page(new Page<>(1, 2),queryWrapper);

        return Result.success(outwordService.page(new Page<>(1, 2), queryWrapper));

    }


    // 新增或者更新
    @PostMapping
    public Result save(@RequestBody Outword outword) {
            return Result.success(outwordService.saveOrUpdate(outword));
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        outwordService.removeById(id);
            return Result.success();
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        outwordService.removeByIds(ids);
            return Result.success();
    }

    @GetMapping
    public Result findAll() {
            return Result.success(outwordService.list());
    }

    @GetMapping("/{id}")
    public Result findOne(@PathVariable Integer id) {
            return Result.success(outwordService.getById(id));
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam Integer pageNum,
                           @RequestParam Integer pageSize) {
            QueryWrapper<Outword> queryWrapper = new QueryWrapper<>();
            queryWrapper.orderByDesc("id");
            return Result.success(outwordService.page(new Page<>(pageNum, pageSize), queryWrapper));
    }

}

