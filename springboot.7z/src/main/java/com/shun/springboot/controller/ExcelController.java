package com.shun.springboot.controller;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shun.springboot.common.Result;

import com.shun.springboot.entity.Excel;
import com.shun.springboot.mapper.ExcelMapper;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.List;

@RestController
@RequestMapping("/excel")
public class ExcelController {

    @Resource
    private ExcelMapper excelService;

//    // 新增或者更新
//    @PostMapping
//    public Result save(@RequestBody Excel excel) {
//        return Result.success(excelService.saveOrUpdate(excel));
//    }
//
//    @DeleteMapping("/{id}")
//    public Result delete(@PathVariable Integer id) {
//        return Result.success(excelService.removeById(id));
//    }
//
//    @PostMapping("/del/batch")
//    public Result deleteBatch(@RequestBody List<Integer> ids) {
//        return Result.success(excelService.removeByIds(ids));
//    }
//
//    @GetMapping
//    public Result findAll() {
//        return Result.success(excelService.list());
//    }
//
//    @GetMapping("/{id}")
//    public Result findOne(@PathVariable Integer id) {
//        return Result.success(excelService.getById(id));
//    }
//
//    @GetMapping("/excelname/{excelname}")
//    public Result findOne(@PathVariable String excelname) {
//        QueryWrapper<Excel> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("excelname",excelname);
//        return Result.success(excelService.getOne(queryWrapper));
//    }

    /**
     * 分页查询接口
     * @param pageNum
     * @param pageSize
     */
    @GetMapping("/page")
    public Result findPage(@RequestParam Integer pageNum,
                           @RequestParam Integer pageSize,
                           @RequestParam(defaultValue = "") String classname,
                           @RequestParam(defaultValue = "") String teachers,
                           @RequestParam(defaultValue = "") String course,
                           @RequestParam(defaultValue = "") String isToday,
                           @RequestParam(defaultValue = "") String classroom) {

        QueryWrapper<Excel> queryWrapper = new QueryWrapper<>();

        if (!"".equals(classname)) {
            queryWrapper.like("classname", classname);
        }
        if (!"".equals(teachers)) {
            queryWrapper.like("teachers", teachers);
        }
        if (!"".equals(course)) {
            queryWrapper.like("course", course);
        }
        if (!"".equals(isToday)) {
            queryWrapper.like("is_today", isToday);
        }
        if (!"".equals(classroom)) {
            queryWrapper.like("classroom", classroom);
        }
        

        return Result.success(excelService.selectPage(new Page<>(pageNum, pageSize), queryWrapper));
    }

    /**
     * 导出接口
     */
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws Exception {
        // 从数据库查询出所有的数据
        List<Excel> list = excelService.selectList(null);
        // 通过工具类创建writer 写出到磁盘路径
//        ExcelWriter writer = ExcelUtil.getWriter(filesUploadPath + "/用户信息.xlsx");
        // 在内存操作，写出到浏览器
        ExcelWriter writer = ExcelUtil.getWriter(true);
        //自定义标题别名
        writer.addHeaderAlias("classname", "班级");
        writer.addHeaderAlias("teachers", "教师");
        writer.addHeaderAlias("course", "课程");
        writer.addHeaderAlias("courseNumber", "课程号");
        writer.addHeaderAlias("isToday", "时间");
        writer.addHeaderAlias("classroom", "教室");
        writer.addHeaderAlias("weeks", "周次");
        writer.addHeaderAlias("sections", "节次");

        // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
        writer.write(list, true);

        // 设置浏览器响应的格式
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("导入的课表整合_临时", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        out.close();
        writer.close();
    }

    /**
     * toPython
     */
    @GetMapping("/inexcel")
    public Result topython() {
        // TODO Auto-generated method stub
        Process procdel;
        try {
            procdel = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\1删数据库.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(procdel.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            procdel.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        Process proc1;
        try {
            proc1 = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\1创建转存表.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc1.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc1.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Process proc2;
        try {
            proc2 = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\2文件写入.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc2.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc2.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Process proc3;
        try {
            proc3 = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\3写入后调整格式.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc3.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc3.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Process proc4;
        try {
            proc4 = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\4数据库转存.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc4.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc4.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        return "完成";
        return Result.success(true);
    }

    @GetMapping("/clean")
    public Result Clean() {
        Process proc;
        try {
            proc = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\2清空数据.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return Result.success(true);
    }
}