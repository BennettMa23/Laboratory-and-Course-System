package com.shun.springboot.controller;


import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shun.springboot.entity.Task;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shun.springboot.common.Result;

import com.shun.springboot.service.IWorkloadService;
import com.shun.springboot.entity.Workload;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@RestController
@RequestMapping("/workload")
public class WorkloadController {
    
    @Resource
    private IWorkloadService workloadService;

    // 新增或者更新
    @PostMapping
    public Result save(@RequestBody Workload workload) {
            return Result.success(workloadService.saveOrUpdate(workload));
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        workloadService.removeById(id);
            return Result.success();
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        workloadService.removeByIds(ids);
            return Result.success();
    }

    @GetMapping
    public Result findAll() {
            return Result.success(workloadService.list());
    }

    @GetMapping("/{id}")
    public Result findOne(@PathVariable Integer id) {
            return Result.success(workloadService.getById(id));
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam Integer pageNum,
                           @RequestParam Integer pageSize,
                           @RequestParam(defaultValue = "") String coursename) {
        QueryWrapper<Workload> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("coursename", coursename);

        queryWrapper.orderByDesc("id");
        return Result.success(workloadService.page(new Page<>(pageNum, pageSize), queryWrapper));
    }

    /**
     * 导出接口
     */
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws Exception {
        // 从数据库查询出所有的数据
        List<Workload> list = workloadService.list();
        // 通过工具类创建writer 写出到磁盘路径
//        ExcelWriter writer = ExcelUtil.getWriter(filesUploadPath + "/用户信息.xlsx");
        // 在内存操作，写出到浏览器
        ExcelWriter writer = ExcelUtil.getWriter(true);
        //自定义标题别名
        writer.addHeaderAlias("classname", "专业班级");
        writer.addHeaderAlias("classnum", "班数");
        writer.addHeaderAlias("professionalcategory", "专业类别");
        writer.addHeaderAlias("coursename", "实验课程名称");
        writer.addHeaderAlias("groupnumbers", "每组人数");
        writer.addHeaderAlias("attributes", "课程类别");
        writer.addHeaderAlias("form", "实验形式");
        writer.addHeaderAlias("experimentalcour", "课程实验学时");
        writer.addHeaderAlias("experimental", "实验总学时");
        writer.addHeaderAlias("selection", "实验学生数");
        writer.addHeaderAlias("manhour", "实验人时数");
        writer.addHeaderAlias("teachername", "教师");

        // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
        writer.write(list, true);

        // 设置浏览器响应的格式
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("工作量统计表", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        out.close();
        writer.close();

    }


    /**
     * toPython
     */
    @GetMapping("/in")
    public Result topython() {
        Process proc;
        try {
            proc = Runtime.getRuntime().exec("python src\\main\\java\\com\\shun\\springboot\\python\\实验室工作量\\demo.py");// 执行py文件
            //用输入输出流来截取结果
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream(),"GBK"));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return Result.success(true);

    }
}

