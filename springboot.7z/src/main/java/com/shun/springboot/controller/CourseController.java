package com.shun.springboot.controller;


import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shun.springboot.entity.User;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shun.springboot.common.Result;

import com.shun.springboot.service.ICourseService;
import com.shun.springboot.entity.Course;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-07
 */

/*@RestController 是@controller和@ResponseBody 的结合
@Controller 将当前修饰的类注入SpringBoot IOC容器，使得从该类所在的项目跑起来的过程中，这个类就被实例化。
@ResponseBody 它的作用简短截说就是指该类中所有的API接口返回的数据，甭管你对应的方法返回Map或是其他Object，它会以Json字符串的形式返回给客户端

@RequestMapping 来映射请求，也就是通过它来指定控制器可以处理哪些URL请求
@Resource注解和@Autowired注解类似，都用来声明需要自动装配的bean

@GetMapping，处理get请求
@PostMapping，处理post请求
@PutMapping，处理put请求
@DeleteMapping，处理delete请求
*/
@RestController
@RequestMapping("/course")
public class CourseController {
    
    @Resource
    private ICourseService courseService;

    // 新增或者更新
    @PostMapping
    public Result save(@RequestBody Course course) {

        long numtemp = 0;

        course.setSelection(numtemp);

        return Result.success(courseService.saveOrUpdate(course));
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        courseService.removeById(id);
            return Result.success();
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        courseService.removeByIds(ids);
            return Result.success();
    }

    @GetMapping
    public Result findAll() {
            return Result.success(courseService.list());
    }

    @GetMapping("/{id}")
    public Result findOne(@PathVariable Integer id) {
            return Result.success(courseService.getById(id));
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam Integer pageNum,
                           @RequestParam Integer pageSize,
                           @RequestParam(defaultValue = "") String classname,
                           @RequestParam(defaultValue = "") String teachername,
                           @RequestParam(defaultValue = "") String coursename) {
        QueryWrapper<Course> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("classname", classname);
        queryWrapper.like("teachername", teachername);
        queryWrapper.like("coursename", coursename);

        queryWrapper.orderByDesc("id");
        return Result.success(courseService.page(new Page<>(pageNum, pageSize), queryWrapper));
    }

    @PostMapping("/selectcourse/{courseId}/{userId}")
    public Result studentCourse(@PathVariable Integer courseId, @PathVariable String userId) {
        long temp = 0;
        long numtemp = 0;
        if (courseId != null) {
            temp = courseService.selNum(courseId);
            if (String.valueOf(temp) != null){
                numtemp = courseService.selNum(courseId);
                numtemp ++ ;
                courseService.addNum(courseId,numtemp);
            }
        }

        courseService.selectCourse(userId, courseId);
        return Result.success();
    }
    @PostMapping("/dropcourse/{courseId}/{userId}")
    public Result dropCourse(@PathVariable Integer courseId, @PathVariable String userId) {
        long temp = 0;
        long numtemp = 0;
        if (courseId != null) {
            temp = courseService.selNum(courseId);
            if (String.valueOf(temp) != null){
                numtemp = courseService.selNum(courseId);
                numtemp -- ;
                courseService.dropNum(courseId,numtemp);
            }
        }


        courseService.dropCourse(null, courseId);
        return Result.success();
    }
    @GetMapping("/selcoursepage")
    public Result selcourse(@RequestParam(defaultValue = "") String userid) {
        QueryWrapper<Course> queryWrapper = new QueryWrapper<>();

        queryWrapper.like("userid", userid);
        return Result.success(courseService.page(new Page<>(1, 50), queryWrapper));
    }

    /**
     * 导出接口
     */
    @GetMapping("/export")
    public void export(HttpServletResponse response) throws Exception {
        // 从数据库查询出所有的数据
        List<Course> list = courseService.list();
        // 通过工具类创建writer 写出到磁盘路径
//        ExcelWriter writer = ExcelUtil.getWriter(filesUploadPath + "/用户信息.xlsx");
        // 在内存操作，写出到浏览器
        ExcelWriter writer = ExcelUtil.getWriter(true);
//        //自定义标题别名
//        writer.addHeaderAlias("username", "用户名");
//        writer.addHeaderAlias("password", "密码");
//        writer.addHeaderAlias("nickname", "昵称");
//        writer.addHeaderAlias("email", "邮箱");
////        writer.addHeaderAlias("phone", "电话");
//        writer.addHeaderAlias("question", "密保问题");
//        writer.addHeaderAlias("answer", "密保答案");
//        writer.addHeaderAlias("createTime", "创建时间");
//        writer.addHeaderAlias("avatarUrl", "头像");


        // 一次性写出list内的对象到excel，使用默认样式，强制输出标题
        writer.write(list, true);

        // 设置浏览器响应的格式
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        String fileName = URLEncoder.encode("课程清单", "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ".xlsx");

        ServletOutputStream out = response.getOutputStream();
        writer.flush(out, true);
        out.close();
        writer.close();

    }

}

