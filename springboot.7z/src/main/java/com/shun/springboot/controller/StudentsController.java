package com.shun.springboot.controller;


import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shun.springboot.entity.User;
import com.shun.springboot.mapper.StudentsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shun.springboot.common.Result;

import com.shun.springboot.service.IStudentsService;
import com.shun.springboot.entity.Students;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
@RestController
@RequestMapping("/students")
public class StudentsController {
    
    @Resource
    private IStudentsService studentsService;


    // 新增或者更新
    @PostMapping("/update")
    public Result save(@RequestBody Students students) {
//        studentsService.saveOrUpdate(students);
        return Result.success(studentsService.saveOrUpdate(students));
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        studentsService.removeById(id);
        return Result.success();
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        studentsService.removeByIds(ids);
            return Result.success();
    }

    @GetMapping("/all")
    public Result findAll() {
            return Result.success(studentsService.list());
    }

    @GetMapping("/{id}")
    public Result findOne(@PathVariable Integer id) {
        return Result.success(studentsService.getById(id));
    }

    @GetMapping("/findone")
    public Result findStu(@RequestParam(defaultValue = "") Integer id) {
        QueryWrapper<Students> queryWrapper = new QueryWrapper<>();
//            queryWrapper.orderByDesc("id");
        if (!"".equals(id)) {
            queryWrapper.eq("id", id);
        }
        return Result.success(studentsService.getMap(queryWrapper));
    }

    @GetMapping("/page")
    public Result findPage(@RequestParam(defaultValue = "") Integer pageNum,
                           @RequestParam(defaultValue = "") Integer pageSize,
                           @RequestParam(defaultValue = "") Integer id) {
            QueryWrapper<Students> queryWrapper = new QueryWrapper<>();
//            queryWrapper.orderByDesc("sid");

        if (!"".equals(id)) {
            queryWrapper.like("id", id);
        }

        return Result.success(studentsService.page(new Page<>(pageNum, pageSize), queryWrapper));
    }

}

