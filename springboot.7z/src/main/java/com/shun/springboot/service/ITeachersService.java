package com.shun.springboot.service;

import com.shun.springboot.entity.Teachers;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
public interface ITeachersService extends IService<Teachers> {

}
