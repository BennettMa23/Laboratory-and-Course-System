package com.shun.springboot.service.impl;

import com.shun.springboot.entity.Outword;
import com.shun.springboot.mapper.OutwordMapper;
import com.shun.springboot.service.IOutwordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-27
 */
@Service
public class OutwordServiceImpl extends ServiceImpl<OutwordMapper, Outword> implements IOutwordService {


}
