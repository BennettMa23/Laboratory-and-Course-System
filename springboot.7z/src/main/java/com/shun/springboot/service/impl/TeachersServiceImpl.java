package com.shun.springboot.service.impl;

import com.shun.springboot.entity.Teachers;
import com.shun.springboot.mapper.TeachersMapper;
import com.shun.springboot.service.ITeachersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
@Service
public class TeachersServiceImpl extends ServiceImpl<TeachersMapper, Teachers> implements ITeachersService {

}
