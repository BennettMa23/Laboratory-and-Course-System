package com.shun.springboot.service.impl;

import com.shun.springboot.entity.Course;
import com.shun.springboot.mapper.CourseMapper;
import com.shun.springboot.service.ICourseService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigInteger;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-07
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course> implements ICourseService {

    @Resource
    private CourseMapper courseMapper;

    /*@Override 的作用是：如果想重写父类的方法，比如toString()方法的话，在方法前面加上@Override 系统可以帮你检查方法的正确性。*/
    @Override
    public void selectCourse(String userid, Integer courseId) {
        courseMapper.selcourse(userid, courseId);
    }

    @Override
    public void dropCourse(String userid, Integer courseId) {
        courseMapper.dropcourse(userid, courseId);
    }

    @Override
    public void addNum(Integer courseId,Long selection) {
        courseMapper.addnum(courseId,selection);
    }

    @Override
    public long selNum(Integer id) {

        return courseMapper.selnum(id);
    }

    @Override
    public void dropNum(Integer courseId, Long selection) {
        courseMapper.dropnum(courseId, selection);
    }

}
