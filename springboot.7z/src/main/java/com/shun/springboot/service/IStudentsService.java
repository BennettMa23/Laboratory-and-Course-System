package com.shun.springboot.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shun.springboot.controller.dto.UserDTO;
import com.shun.springboot.entity.Students;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */

public interface IStudentsService extends IService<Students> {

}
