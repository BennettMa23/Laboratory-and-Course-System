package com.shun.springboot.service.impl;

import com.shun.springboot.entity.Workload;
import com.shun.springboot.mapper.WorkloadMapper;
import com.shun.springboot.service.IWorkloadService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@Service
public class WorkloadServiceImpl extends ServiceImpl<WorkloadMapper, Workload> implements IWorkloadService {

}
