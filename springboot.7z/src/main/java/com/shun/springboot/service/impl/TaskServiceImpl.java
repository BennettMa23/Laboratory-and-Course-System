package com.shun.springboot.service.impl;

import com.shun.springboot.entity.Task;
import com.shun.springboot.mapper.TaskMapper;
import com.shun.springboot.service.ITaskService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@Service
public class TaskServiceImpl extends ServiceImpl<TaskMapper, Task> implements ITaskService {

}
