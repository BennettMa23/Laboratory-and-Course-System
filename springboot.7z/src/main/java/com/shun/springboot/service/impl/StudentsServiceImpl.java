package com.shun.springboot.service.impl;

import com.shun.springboot.controller.dto.UserDTO;
import com.shun.springboot.entity.Students;
import com.shun.springboot.mapper.StudentsMapper;
import com.shun.springboot.service.IStudentsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
@Service
public class StudentsServiceImpl extends ServiceImpl<StudentsMapper, Students> implements IStudentsService {

}
