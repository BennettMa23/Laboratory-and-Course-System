package com.shun.springboot.service;

import com.shun.springboot.entity.Coustatistics;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
public interface ICoustatisticsService extends IService<Coustatistics> {

}
