package com.shun.springboot.service;

import com.shun.springboot.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-12
 */
public interface IMenuService extends IService<Menu> {

    List<Menu> findMenus(String name);
}
