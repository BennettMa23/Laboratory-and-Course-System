package com.shun.springboot.service;

import com.shun.springboot.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;

import java.math.BigInteger;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-07
 */
public interface ICourseService extends IService<Course> {

    void selectCourse(String userid, Integer courseId);

    void dropCourse(String userId, Integer courseId);

    void addNum(Integer courseId,Long selection);

    long selNum(Integer id);

    void dropNum(Integer courseId,Long selection);
}
