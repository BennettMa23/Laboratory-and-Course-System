package com.shun.springboot.exception;

import lombok.Getter;

/**
 * 自定义异常
 */
@Getter
public class ServiceException extends RuntimeException {
    private String code;

    public ServiceException(String code, String msg) {
        super(msg);
        this.code = code;
        /*this 只能调用自身的构造方法；
        super 可以调用父类的构造方法。
        */
    }

}

