package com.shun.springboot.common;

public enum RoleEnum {
    ROLE_ADMIN,ROLE_STUDENT,ROLE_TEACHER;
}
