package com.shun.springboot.utils;

public class AndClass {
    public static String classroom(String name) {
        String str1 = name.substring(0, name.length() -1);
//        System.out.println("->"+str1);
        String str2 = name.substring(name.length()-1);

        int temp = Integer.parseInt(str2);
        if (temp % 2 != 0)
            temp ++;
        else
            temp --;
//        System.out.println(temp);

        String strand = str1 + temp;
//        System.out.println(strand);
        return strand;
    }
}
