package com.shun.springboot.mapper;

import com.baomidou.mybatisplus.annotation.TableField;
import com.shun.springboot.entity.Course;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Update;

import java.math.BigInteger;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-07
 */
public interface CourseMapper extends BaseMapper<Course> {

//    @Insert("INSERT INTO select_course VALUES (#{courseId},#{userid})")
//    void selcourse(BigInteger userid, BigInteger courseId);

    @Update("update course set userid = #{userid} where id = #{courseId}")
    void selcourse(String userid, Integer courseId);

    @Update("update course set userid = #{userid} where id = #{courseId}")
    void dropcourse(String userid, Integer courseId);

    long selnum(Integer courseId);

    void addnum(Integer courseId,Long selection);

    void dropnum(Integer courseId, Long selection);
}
