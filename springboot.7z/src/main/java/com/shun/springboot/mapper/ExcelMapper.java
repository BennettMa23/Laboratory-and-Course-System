package com.shun.springboot.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shun.springboot.entity.Excel;


// @Mapper
public interface ExcelMapper extends BaseMapper<Excel> {

}
