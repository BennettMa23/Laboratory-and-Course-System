package com.shun.springboot.mapper;

import com.shun.springboot.entity.Students;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shun.springboot.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
//@Mapper
public interface StudentsMapper extends BaseMapper<Students> {

//    @Select("SELECT * FROM bzu_students WHERE sid = #{id}")
//    List<Students> findStu(User user);

}
