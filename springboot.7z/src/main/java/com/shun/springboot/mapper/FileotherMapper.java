package com.shun.springboot.mapper;

import com.shun.springboot.entity.Fileother;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface FileotherMapper extends BaseMapper<Fileother> {

}
