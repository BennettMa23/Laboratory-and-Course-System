package com.shun.springboot.mapper;

import com.shun.springboot.entity.Article;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-17
 */
public interface ArticleMapper extends BaseMapper<Article> {

}
