package com.shun.springboot.mapper;

import com.shun.springboot.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
