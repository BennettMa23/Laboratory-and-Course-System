package com.shun.springboot.mapper;

import com.shun.springboot.entity.Fileimplement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-03
 */
public interface FileimplementMapper extends BaseMapper<Fileimplement> {

}
