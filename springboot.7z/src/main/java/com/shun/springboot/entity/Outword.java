package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-27
 */
@Getter
@Setter
  @ApiModel(value = "Outword对象", description = "")
public class Outword implements Serializable {

    private static final long serialVersionUID = 1L;

    private String classname;

    private String teachers;

    private String course;

    @TableField(value = "course_number")
    private String courseNumber;

    @TableField(value = "is_today")
    private String isToday;

    private String classroom;

    private String weeks;

    private String sections;

      @TableId(value = "id", type = IdType.AUTO)
      private Integer id;


}
