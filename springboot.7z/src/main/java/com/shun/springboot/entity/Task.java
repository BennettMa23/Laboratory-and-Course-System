package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@Getter
@Setter
@TableName("list_task")
@ApiModel(value = "Task对象", description = "")
public class Task implements Serializable {

    private static final long serialVersionUID = 1L;

    private String profession;

    private String number;

    private String coursename;

    private String yesno;

    private Double experimental;

    private Integer projectnum;

    private Integer partprojectnum;

    private String classname;

    private Integer man;

    private String edu;

    private Integer repeatnum;

    private Integer groups;

    private Integer danwei;

      @TableId(value = "id", type = IdType.AUTO)
      private Integer id;


}
