package com.shun.springboot.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-07
 */
@Getter
@Setter
  @ApiModel(value = "Course对象", description = "")
public class Course implements Serializable {

    private static final long serialVersionUID = 1L;

    private String number;

    private Long sequence;

    private String coursename;

    private String teachernumber;

    private String teachername;

    private String title;

    private String facultyanddepartments;

    private Double language;

    private String attributes;

    private String exam;

    private String classname;

    private Long capacity;

    private Double hours;

    private Long weekhours;

    private Long teachinghours;

    private Long computertime;

    private Long experimental;

    private Double credit;

    private String classroom;

    private String weeks;

    private Long selection;

    @TableId(type = IdType.AUTO)//主键
    private Integer id;

    private String userid;
}
