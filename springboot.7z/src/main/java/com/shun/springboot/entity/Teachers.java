package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
@Getter
@Setter
  @TableName("bzu_teachers")
@ApiModel(value = "Teachers对象", description = "")
public class Teachers implements Serializable {

    private static final long serialVersionUID = 1L;

      @ApiModelProperty("教职工号")
      private Long id;

      @ApiModelProperty("姓名")
      private String name;

      @ApiModelProperty("性别")
      private String sex;

      @ApiModelProperty("出生日期")
      private LocalDate birth;

      @ApiModelProperty("学位")
      private String science;

      @ApiModelProperty("职称")
      private String grade;

      @ApiModelProperty("毕业院校")
      private String school;

      @ApiModelProperty("专业")
      private String profession;

      @ApiModelProperty("教授课程")
      private String coursename;

      @ApiModelProperty("院系")
      private String department;

      @ApiModelProperty("联系电话")
      private Long phone;

      @ApiModelProperty("地址")
      private String address;


}
