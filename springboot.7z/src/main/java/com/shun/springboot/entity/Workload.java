package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@Getter
@Setter
  @TableName("list_workload")
@ApiModel(value = "Workload对象", description = "")
public class Workload implements Serializable {

    private static final long serialVersionUID = 1L;

    private String classname;

    private Integer classnum;

    private String professionalcategory;

    private String coursename;

    private Integer groupnumbers;

    private String attributes;

    private String form;

    private Double experimentalcour;

    private Integer experimental;

    private Integer selection;

    private Integer manhour;

    private String teachername;

      @TableId(value = "id", type = IdType.AUTO)
      private Integer id;


}
