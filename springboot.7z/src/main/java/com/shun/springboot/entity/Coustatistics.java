package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-05-08
 */
@Getter
@Setter
  @TableName("list_coustatistics")
@ApiModel(value = "Coustatistics对象", description = "")
public class Coustatistics implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private String number;

    private String coursename;

    private String attributes;

    @ApiModelProperty("项目数")
    private Double projectnum;

    private String partprojectnum;

    @ApiModelProperty("专业")
    private String specialty;

    private Integer specialtynum;


}
