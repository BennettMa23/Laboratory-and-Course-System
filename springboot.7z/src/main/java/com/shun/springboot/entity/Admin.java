package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 
 * </p>
 *
 * @author 马百顺
 * @since 2022-04-26
 */
@Getter
@Setter
  @TableName("bzu_admin")
@ApiModel(value = "Admin对象", description = "")
public class Admin implements Serializable {

    private static final long serialVersionUID = 1L;

      @ApiModelProperty("管理员id")
        private Long id;

      @ApiModelProperty("姓名")
      private String name;

      @ApiModelProperty("手机号")
      private String phone;


}
