package com.shun.springboot.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName(value = "in_excel")
public class Excel {

    private String classname;
//    @JsonIgnore//隐藏
    private String teachers;
    private String course;
    @TableField(value = "course_number")
    private String courseNumber;
    @TableField(value = "is_today")
    private String isToday;
    private String classroom;
    private String weeks;
    private String sections;

    @TableId(type = IdType.AUTO)//主键
    private Integer id;
}
